drop table person cascade constraints;
create table person(id int, name varchar(10), age int, email varchar(90), salary int);
insert into person values(1,'vijay',22,'v@gamil.com', 20000);
insert into person values(2,'ramu',25,'r@gamil.com',50000);
insert into person(salary, name, id, age, email) values(25000,'rohit',3,30,'rt@gmail.com');
insert into person (name,age) values('naveen',50);
insert into person(email, age , id) values('abc@yahoo.com',24,10);
select *from person;
select *from person where name = 'rohit';
select *from person order by age;
select *from person order by name;
select *from person order by age asc;
select *from person order by name asc;
select name as firt_name from person;
select *from person where id>1 and name is not null;
select *from person where id>1 or name is not null;

/***********SQL Function************/
/*****COUNT()****/
select count (*) from person;
select count (name) from person;
select count (salary) from person;
select salary from person;

/*****SUM()****/
select sum (salary) from person;
select sum(salary)/count(salary) from PERSON; 

/*****MAX()****/
select max(salary) from PERSON;

/*****MIN()****/

select min(salary) from person;

/**AVG()***/
select avg(salary) from PERSON;

/*some uses of sql functions**/
select name from person where salary = 35000;
select name from person where salary = (select max(salary)from person);
select name from person where salary = 20000;
select name from person where salary = (select min(salary)from person);
select max(salary) from person where salary=(select max(salary)from person);
select min(salary) from person where salary =(select min(salary)from person);
select max(salary) from person where salary < (select max(salary)from person);
select max(salary) from person where salary < (select max(salary)from person); /*value is null*/
select min(salary) from person where salary > (select min(salary)from person);
select min(salary) from person where salary < (select min(salary)from person); /*valu is null*/


/*SQL without constraint*/
drop table tab1 cascade constraints;
create table tab1(id int, name varchar(90));
insert into tab1 values(1,'abc');
insert into tab1 values(1,'acb');
insert into tab1(name) values('xyz');
insert into tab1(id) values(2);
select *from tab1;

/*SQL with constraint*/
/*NOT NULL
 * Valuse should not be null
 * Values duplicate allowed*/
drop table tab2 cascade constraints;
create table tab2 (id int not null, name varchar(90));
insert into tab2 values(1,'abc');
insert into tab2 values(1,'abc');
insert into tab2 (name) values(2);


/*UNIQUE KEY - 
 * Any number of null value
 * value is not duplicate
 * */
drop table tab3 cascade constraints;
create table tab3(id int, name varchar(90) unique);
insert into tab3 values(1,'abc');
/*insert into tab3 values(1,'abc'); error*/
/*insert into tab3 values(2,'abc') error*/
insert into tab3 values(2,'ab')


/*Combination of NOT NULL and UNIQUE*/
/*1st approach*/
drop table tab4 cascade constraints;
create table tab4(id int not null, name varchar(90) unique);
insert into tab4 values(1,'abc');
insert into tab4 values(1,'abc');
insert into tab4 values(1, 'ab');
insert into tab4 (id) values(2);
insert into tab4 values(1,'');
insert into tab4 values(3,'');
insert into tab4 values(4,'');
insert into tab4 values(5,'');

/*2nd approach*/
drop table tab5 cascade constraints;
create table tab5(id int not null unique, name varchar(90));
insert into tab5 values(1,'abc');
insert into tab5 values(2,'abc');
insert into tab5 values(1,'abc');

/*3rd approach*/
drop table tab6 cascade constraints;
create table tab6(id int not null unique, name varchar(90)not null unique);
insert into tab6 values(1,'abc');
insert into tab6 values(2,'abc');
insert into tab6 (name)values('xyz');


/*Primary Key = not null + unique key*/
drop table tab7 cascade constraint;
create table tab7(id int, name varchar(90)primary key);
insert into tab7 values(1, 'abc');
/*insert into tab7 values(1,'abc');error**/
insert into tab7 values(1,'ab');

/*some important conditon**/
drop table tab8 cascade constraints;
create table tab8(id int unique, name varchar(90) unique);
create table tab9(id int primary key, name varchar(90) primary key);

/*Composit Key - A key with multiple column but combination value should not be same but also allowed to null values*/
/*Composite primary key*/
drop table tab10 cascade constraints;
create table tab10(id int, name varchar(90), constraint TUK1 unique(id, name));
insert into tab10 values(1,'abc');
insert into tab10 values(1,'abc');
insert into tab10 values(1,'ab');
insert into tab10(id) values(1);
insert into tab10(name)values('abc')
insert into tab10 values('','');

/*COMPOSIT parimary KEY - A key with multiple column but combination should not be same and null*/
drop table tab11 cascade constraints;
create table tab11(id int, name varchar(90), constraint tpk1 primary key(id, name));
insert into tab11 values(1,'abc');
insert into tab11 values(1,'abc');
insert into tab11 values(1,'ab');
insert into tab11 values(2,'abc');
insert into tab11 values('ab'); /*because of primary key should be not null*/

/*E FOREIGN KEY
 * ONE TO ONE RELATIONSHIP - eg. One Student have One Address
 * one to one relation ship both table sid value should be unique or primary key
 * Any number of foreign key in same table*/
drop table student cascade constraints;
drop table address cascade constraints;
create table student (id int unique, first_name varchar(90), last_name varchar(90), age int);
create table address (id int unique, house_no varchar(90), city varchar(90), state varchar(90), 
constraint fk1 foreign key(id) references student(id));

insert into student values(1,'ramu','b',28);
insert into address values(1,'123/b','bangalore','karnataka');
insert into student values(2,'vijay','c',23);
insert into address values(2,'23/a','bangalore','karnataka');
select *from student;
select *from address;
delete from student where id = 2;
delete from address where id = 2;
delete from student where id = 2;
/*drop table student;
drop table address;
drop table student;*/

/*b ONE to many or many to one relationship - one student have multiple mail account*/
drop table person cascade constraints;
drop table mail cascade constraints; 
create table person(id int unique, first_name varchar(90), last_name varchar(90), sid int);
create table mail(mail_id varchar(90),username varchar(90), password varchar(90), sid int, 
constraint mfk1 foreign key(sid)references person(id));

/*ctrl+spasec for automatically table show*/
insert into person values(1,'ramu','b',34);
insert into mail values('ramu@gamil.com','ramu6','123',1);
insert into mail values('ramu@hotmail.com','ramuhot','123',1);
insert into person values(2,'vijay','c',45);
insert into mail values('vijay@gamil.com','vi','12',2);
insert into mail values('vijay@rediff.com','vi','12',2);
insert into mail values('vijay@yahoo.co.in','dd','ee','');
select *from mail;
select *from person;
select *from person where id = 2;
select *from mail where sid=2;
delete *from person where id = 2; /*it should not be delete because of this table associate with their child table it means depend to child table first delete the child table after delete parent table*/


/*MANY TO MANAY RELATIONSHIP*/
drop table s_b cascade constraints;
drop table student1 cascade constraints;
drop table batch cascade constraints;
create table student1(s_id int unique, first_name varchar(90), last_name varchar(90),age int);
create table batch(b_id int unique, title varchar(90), duration int, fee int);

create table s_b(s_id int, b_id, 
constraint s_bfk1 foreign key(s_id) references student1(s_id),
constraint s_bfk2 foreign key(b_id) references batch(b_id));

/*first insert student table*/
insert into STUDENT1 values(1,'ramu','k',24);
insert into STUDENT1 values(2,'vijay','b',23);
insert into STUDENT1 values(3, 'babu','b',24);
insert into STUDENT1 values(4,'manu','m',23);

/*second insert batch table*/

insert into BATCH values(1,'regualr',150,10000);
insert into BATCH values(2,'weekend',250,15000);

/*third insert s_b which is called intermediate table*/
insert into s_b values(1,1);
insert into S_B values(1,2);
insert into S_B values(2,2);
insert into S_B values(3,1);
insert into S_B values(3,2);


/*Queries of student1, batch and s_b table which represent many to many relationship*/
select *from S_B;
select *from STUDENT1 where s_id in (select s_id from S_B where b_id=1); 
/*in caluse pass to student1 table multiple values*/
select *from student1 where s_id in(select s_id from s_b where b_id = (select b_id from batch where title ='regualr'));
select *from BATCH where b_id in(select b_id from s_b where s_id=(select s_id from STUDENT1 where first_name ='ramu'));
select *from batch where b_id in(select b_id from s_b where s_id=(select s_id from STUDENT1 where first_name='manu'));
select *from batch where b_id in(select b_id from S_B where s_id=(select s_id from STUDENT1 where first_name ='vijay'));

/*SQL Jonis
 * A one to one Realtionship
 * Queries*/
drop table student cascade constraint;
create table student(id int unique, name varchar(90), age int);
create table address(id int unique, house_no varchar(90), city varchar(90), constraint AFK1 foreign key (id) references student(id));
insert into student values(1,'vijay',24);
insert into student values(2,'ramu',23);
insert into student values(3,'babu',27);

insert into ADDRESS values(1,'123/b','bangalore');
insert into ADDRESS values(2,'145/a','bangalore');
insert into ADDRESS(house_no, city) values('104/d','bangalore');
select *from STUDENT;
select *from ADDRESS;

/*inner join*/
select *from student inner join address on student.id = ADDRESS.id;
/*aliase select *from student s inner join address a on s.id = a.id;*/

/*left outer join*/
 select *from STUDENT left outer join ADDRESS on STUDENT.id = ADDRESS.id;
/*right outer join*/
select *from STUDENT right outer join address on STUDENT.id = ADDRESS.id;
/*full outer join*/
select *from STUDENT full outer join ADDRESS on STUDENT.id = ADDRESS.id;


/*One to many relationship**/
drop table project cascade constraint;
create table project (pid int unique, pname varchar(90), pduration int);
drop table employee;
create table employee(eid int unique, ename varchar(90), age int, epid int, constraint afk2 foreign key(epid) references project(pid));

insert into project values(1,'lara',300);
insert into project values(2,'rst',500);
insert into project(pname,pduration)values('city',400);

insert into employee values(1,'vijay',23,1);
insert into employee values(2,'raju',23,2);
insert into employee values(3,'ramu',23,2);
insert into employee values(4,'babu',23,1);
insert into employee values(5,'vivek',23,2);

select *from project;
select *from employee;

select pname from project where pid=(select epid from employee where ename='vijay');
select ename from employee where epid=(select pid from project where pname ='lara');
select *from project;
select *from employee;
insert into employee(eid,ename,age) values(6,'raj',34);

select *from employee e inner join project p  on e.epid=p.pid;
select *from employee e left outer join project p on e.epid=p.pid;
select *from employee e right outer join project p on e.epid = p.pid;
select *from employee e full outer join project p on e.epid= p.pid;

/*many to many realtionship*/
drop table student cascade constraint;
drop table batch cascade constraint;
create table batch(bid int unique, title varchar(90), duration int);
create table student(sid int unique, name varchar(90), age int);

insert into batch values(1,'java',120);
insert into BATCH values(2,'j2ee',500);
insert into BATCH values(3,'.net',120);


insert into STUDENT values(1,'ramu',23);
insert into STUDENT values(2,'babu',25);
insert into student values(3,'vijay',34);
insert into student values(4,'ramu',23);

create table b_s(	bid int, 
						sid int, 
						constraint b_sfk1 foreign key(bid) references batch(bid),
						constraint b_sfk2 foreign key(sid) references student(sid)
					);

insert into b_s values(1,1);
insert into b_s values(2,1);
insert into b_s values(2,2);
insert into b_s values(1,3);

select *from STUDENT;
select *from B_S;

select *from STUDENT where sid in(select sid from b_s where bid=1);
select *from STUDENT where sid in(select sid from b_s where bid=(select bid from batch where title='java'));

select *from student inner join b_s on b_s.sid=student.sid inner join batch on batch.bid=b_s.bid where batch.bid=1;
select *from b_s, student, batch where b_s.sid=student.sid and b_s.bid=batch.bid and batch.bid=1;

select *from batch where bid in(select sid from b_s where sid = 1);
select *from batch where bid in(select sid from b_s where sid=(select sid from student where name='vijay'));

select *from batch b inner join b_s bs on b.bid=bs.bid;
select *from batch b inner join b_s bs on b.bid=bs.bid inner join student s on bs.sid=s.sid;

select *from batch b left outer join b_s bs on b.bid=bs.bid;
select *from batch b left outer join b_s bs on b.bid=bs.bid inner join student s on bs.sid=s.sid;

select *from batch b right outer join b_s bs on b.bid=bs.bid;
select *from batch b right outer join b_s bs on b.bid=bs.bid inner join student s on bs.sid=s.sid;



/**********SELF JOIN*******/
/**three type of creating tables add primary key and foreign key before creating table or after creating table*/
drop table employee1 cascade constraints;
create table employee1(empid int, 
empname varchar2(20), 
mgr_id int,

constraint emppk primary key(empid),
constraint empfk foreign key(mgr_id) references employee1(empid)
);

drop table employee1 cascade constraints;
create table employee1(
empid int primary key, 
empname varchar2(20), 
mgr_id int references employee1(empid)
);


drop table employee1 cascade constraints;
create table employee1(
empid int, 
empname varchar2(20), 
mgr_id int
);

alter table employee1 add constraint emppk primary key(empid);
alter table employee1 add constraint empfk foreign key(mgr_id) references employee1(empid);  

/********end **********/
drop table employee cascade constraint;
create table employee(id int, name varchar(90), age int, mgr_id int, constraint ep primary key(id),
												constraint ef foreign key (mgr_id)references employee(id));

insert into employee(id, name, age) values(1,'vijay',22);
insert into EMPLOYEE values(2,'ram',24,1);
insert into EMPLOYEE values(3,'ravi',34,1);
insert into employee values(4,'shyam',56,3);
insert into employee values(5,'kavi',34,4);
insert into employee values(6,'vikaram',34,4);
insert into employee values(7,'don',34,6);
insert into employee values(8,'lara',34,7);
insert into employee values(9,'nisha',34,8);
insert into employee values(10,'kiran',34,10);
insert into employee values(11,'smita',34,9);

select *from EMPLOYEE;
select A.name, B.name from employee A inner join employee B on A.mgr_id=b.id;

select A.name, B.name from employee A left outer join employee B on A.mgr_id=b.id;

select A.name as name, nvl(b.name,'Top Level Manager')as manager from employee A left outer join employee B on a.mgr_id=b.id;


delete from employee; /*listening to transaction methods it is dml command before commit command data rollback*/
drop table employee; /*delete the table it is ddl command*/
truncate table employee;/*not listening to transcation mentod ddl command*/


drop table orders;
drop table customer;

create table customer(id int primary key, name varchar(90), age int);
create table orders(id int, qty int, c_id int, constraint cf foreign key(c_id) references customer(id));

insert into customer values(1,'vijay', 22);
insert into customer values(2,'ravi',34);
insert into customer values(3,'naveen',23);

insert into ORDERS values(1,100,1);
insert into ORDERS values(2,200,1);
insert into orders values(3,150,1);

insert into ORDERS values(4,1000,2);
insert into orders values(5,120,2);

insert into ORDERS values(6,200,3);

select *from orders;
select *from CUSTOMER;

select name from customer where id in (select c_id from orders group by(c_id)having count(c_id)>1);

/*pageination concept*/
select *from orders where rownum<3;
select *from(select rownum rn, id, qty, c_id from orders) where rn between 3 and 6;



/*new table*/
drop table tab201;
create table tab201(sno int, name varchar(90), age int);


insert into tab201 values(1, 'abc', 22);
insert into tab201 values(1, 'abc', 22);
insert into tab201 values(1, 'abc', 22);
insert into tab201 values(1, 'abc', 22);
insert into tab201 values(2, 'abc', 22);
insert into tab201 values(2, 'abc', 22);
insert into tab201 values(2, 'abc', 22);
insert into tab201 values(2, 'abc', 22);
insert into tab201 values(2, 'abc', 22);


select rowid from tab201; 

select from tab201 where rowid ='AAFXXXAABAAALMBAAAA';

select *from tab201;

select min(rowid)from tab201 group by (sno,name,age);
select *from tab201 where rowid not in(select min(rowid) from tab201 group by(sno, name, age));

select *from tab201;


/*create new table*/
drop table tab206;
create table tab206(sno int, gender varchar(100));
insert into tab206 values(1,'m');
insert into tab206 values(2,'f');
insert into tab206 values(3,'m');
insert into tab206 values(4,'f');
insert into tab206 values(5,'m');

update tab206 set gender = case gender when 'm' then 'f' else 'm' end;
select *from tab206;

/*create new table*/
drop table tab301;
create table tab301(sno int, name varchar(90), salary int);
insert into tab301 values(1,'abc',2000);
insert into tab301 values(2,'xyz',4000);
insert into tab301 values(3,'test',6000);
insert into tab301 values(4,'vijay',7000);
insert into tab301 values(5,'manu',1000);

/*if get ranking the value**/
select sno, name, salary, rank() over (order by salary desc) ranking from tab301;

select *from(select sno, name, salary, dense_rank() over(order by sno)rank from tab301) 
where rank in trunc((select count(*)/2 from tab301))*1;


/*PROJECT DEVELPMENT START*/

/*1ST Table*/

drop sequence gender_seq;
create sequence gender_seq increment by 1 start with 1;
create table gender(id int unique, name varchar(90));

insert into gender values(gender_seq.nextval,'male');
insert into gender values(gender_seq.nextval,'female');

select *from gender;

/*2nd Table*/

drop sequence skill_seq;
create sequence skill_seq increment by 1 start with 1;

drop table skill;
create table skill(id int unique, name varchar(90));

insert into skill values(skill_seq.nextval,'c');
insert into skill values(skill_seq.nextval,'c++');
insert into skill values(skill_seq.nextval,'java');
insert into skill values(skill_seq.nextval,'.Net');
insert into skill values(skill_seq.nextval,'Oralce');
insert into skill values(skill_seq.nextval,'html');
insert into skill values(skill_seq.nextval,'CSS');
insert into skill values(skill_seq.nextval,'Java Script');

select *from skill;
/*3rd Table*/

drop sequence edu_seq;
create sequence edu_seq increment by 1 start with 1;

drop table education;
create table education(id int unique, name varchar(90));

insert into education values(edu_seq.nextval,'B.Tech');
insert into education values(edu_seq.nextval,'MCA');
insert into education values(edu_seq.nextval,'M.Tech');
insert into education values(edu_seq.nextval,'MBA');
insert into education values(edu_seq.nextval,'BCA');

select *from education;

/*project table*/

drop table PROJECT;
drop sequence project_seq;
create sequence project_seq increment by 1 start with 1;
create table project(id int unique, name varchar(90), duration int, start_date date);

insert into PROJECT values(project_seq.nextval,'city', 100, to_date('01-09-2014','DD-MM-YYYY'));
insert into project values(project_seq.nextval,'hdfc', 400, to_date('20-05-2015','DD-MM-YYYY'));
insert into project values(project_seq.nextval,'axis', 300, to_date('21-03-2015','DD-MM-YYYY'));


/*Create Employee Table*/
drop sequence employee_seq;
create sequence employee_seq increment by 1 start with 1;
drop table employee;
create table employee(id int unique, first_name varchar(90), 
last_name varchar(90),
date_birth timestamp,
gender_id int,
latest_education_id int,
joining_date date,
project_id int,
username varchar(90),
passweord varchar(90),
constraint emp_fk1 foreign key(gender_id)references gender(id),
constraint emp_fk2 foreign key(latest_education_id)references education(id),
constraint emp_fk3 foreign key(project_id)references PROJECT(id));


/*Create address table and sequence*/
drop sequence address_seq;
create sequence address_seq increment by 1 start with 1;
drop table address1 cascade constraints;
create table address1(id int unique,
house_no varchar(90),
street_name varchar(90),
city varchar(90),
state varchar(90),
employee_id int,
constraint address_fk foreign key(employee_id) references employee(id));



/*INSERT Value in Employee table*/
insert into EMPLOYEE values(employee_seq.nextval, 'ramu','kodel',
to_timestamp('01-01-1990 4:24:24','DD-MM-YYYY HH24:MI:SS'),1,1, to_date('01-01-1990','DD-MM-YYYY'),1,'ramu','kodela');



