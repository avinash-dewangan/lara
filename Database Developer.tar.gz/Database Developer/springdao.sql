
drop table gender cascade constraints;
create table gender (id int unique, name varchar(90));
insert into gender values(1, 'male');
insert into gender values(2, 'Female');

drop table skills cascade constraints;
create table skills(id int unique, name varchar(90));
insert into skills values(1, 'C');
insert into skills values(2, 'C++');
insert into skills values(3, 'Java');
insert into skills values(4, 'Oracle');

drop table education cascade constraints;
create table education(id int unique, name varchar(90));
insert into education values(1, 'MCA');
insert into education values(2, 'BE');
insert into education values(3, 'MBA');


drop table users cascade constraints;
create table users(
id int unique, 
name varchar(90), 
age int, 
email varchar(90),
gender_id int,
education_id int,
constraint uf1 foreign key(gender_id) references gender(id), 
constraint uf2 foreign key(education_id)references education(id)
);

drop table users_skills cascade constraints;
create table users_skills(
u_id int, 
s_id int, 
constraint usf1 foreign key(u_id) references users(id),
constraint usf2 foreign key(s_id) references skills(id)
);


select u.id, u.name, u.age, u.email, u.gender_id, u.education_id from users u 
inner join users_skills us on u.id=us.u_id and u.id =2 order by u.id;

select u.id, u.name, u.age, u.email, g.name, e.name 
from users u, genders g, educations e, skills s users_skills us 
where u.gender_id = g.id 
and u.education_id = e.id 
and u.id = us.u_id 
and us.u_id = s.id 
order by u.id=us.u_id 
and us.u_id=s.id order by u.id;


delete users;
delete users_skills;