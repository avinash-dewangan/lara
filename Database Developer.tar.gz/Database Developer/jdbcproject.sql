/--Master Table-/
drop table gender cascade constraints;
drop sequence gender_seq;
create sequence gender_seq increment by 1 start with 1;
create table gender(id int unique, name varchar(10));
insert into gender values(gender_seq.nextval,'male');
insert into gender values(gender_seq.nextval,'female');
select *from gender;


/--Master Table-/
drop table skill cascade constraints;
drop sequence skill_seq;
create sequence skill_seq
 start with     1
 increment by   1
 nocache
 nocycle;
 
create table skill(id int unique, name varchar(20));
insert into skill values(skill_seq.nextval,'C');
insert into skill values(skill_seq.nextval,'C++');
insert into skill values(skill_seq.nextval,'JAVA');
insert into skill values(skill_seq.nextval,'ORACLE');
/------------------------------------------------/


/--Master Table-/
drop table education cascade constraints;
drop sequence education_seq;

create sequence education_seq increment by 1 start with 1;
create table education(id int unique, name varchar(20));
insert into education values(education_seq.nextval,'B.Tech');
insert into education values(education_seq.nextval,'M.Tech');
insert into education values(education_seq.nextval,'MCA');
insert into education values(education_seq.nextval,'BCA');
select *from education;
/------------------------------------------------/



/--Master Table-/
drop table project cascade constraints;
drop sequence project_seq;
create sequence project_seq increment by 1 start with 1;
create table project(id int unique, name varchar(20), duration int, start_date date);
INSERT INTO project VALUES(project_seq.nextval, 'star',345, to_date('04-06-2016','dd-mm-yyyy'));
INSERT INTO project VALUES(project_seq.nextval, 'star',345, to_date('01-06-2016','dd-mm-yyyy'));


/------------------------------------------------/

/--Transcation Table-/
drop table employee cascade constraints;
drop sequence employee_seq;
create sequence employee_seq increment by 1 start with 1;
create table employee(
id int unique,
first_name varchar(30), 
last_name varchar(30),
date_birth timestamp,
gender_id,
latest_edcuation_id,
joining_date date,
project_id int,
user_name varchar(30),
password varchar(30),
constraint emp_fk1 foreign key (gender_id)references gender(id),
constraint emp_fk2 foreign key (latest_edcuation_id) references education(id),
constraint emp_fk3 foreign key (project_id) references project(id)
);

/--Transacation Table-/
drop table address cascade constraints;
drop sequence address_seq;
create sequence address_seq increment by 1 start with 1;
create table address(id int unique, 
house_no varchar(30),
street_name varchar(30),
city varchar(30),
state varchar(30),
employee_id int unique, 
constraint address_fk1 foreign key (employee_id) references employee(id)
);
/-----------------------------------/

/--Intermediate Table- Employee and skill table-/
drop table employee_skill cascade constraints;
create table employee_skill(employee_id int, skill_id int,
constraint es_fk1 foreign key(employee_id) references employee(id),
constraint es_fk2 foreign key(skill_id) references skill(id)
);

/------------------------------------------------/
