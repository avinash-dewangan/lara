create sequence gender_seq increment by 1 start with 1;
create table gender(id int unique, name varchar(10));
insert into gender values(gender_seq.nextval,'male');
insert into gender values(gender_seq.nextval,'female');
select *from gender;
/------------------------------------------------/
create sequence skill_seq
 start with     1
 increment by   1
 nocache
 nocycle;
 
create table skill(id int unique, name varchar(20));
insert into skill values(skill_seq.nextval,'MCA');
insert into skill values(skill_seq.nextval,'B.Tech');
insert into skill values(skill_seq.nextval,'BCA');
insert into skill values(skill_seq.nextval,'M.Tech');


