create table student
(
	id int,
	name varchar(10),
	constraint primary key(id)
)

create table skill
(
	id int,
	name varchar(10),
	constraint primary key(id)
)

create table student_skill
(
	studentid int,
	skillid int,
	constraint fk foreign key(studentid) references skill(id),
	constraint fk1 foreign key(skillid) references student(id)
) 

insert into student values(1,'a');
insert into student values(2,'b');
insert into student values(3,'c');
insert into student values(4,'d');

select *from student;

insert into skill values(1,'java');
insert into skill values(2,'sql');
insert into skill values(3,'html');

select *from skill;

/*join the all three table*/

INSERT INTO student_skill VALUES(1,1);
INSERT INTO student_skill VALUES(1,2);
INSERT INTO student_skill VALUES(2,1);
INSERT INTO student_skill VALUES(2,3);


/*INNER JOIN for join three table*/
SELECT skill.name, student.name
FROM student
INNER JOIN student_skill
INNER JOIN skill ON student.id=student_skill.studentid AND skill.id = student_skill.skillid;

SELECT skill.name, student.name
FROM student, skill, student_skill
WHERE student.id=student_skill.studentid AND skill.id=student_skill.skillid;



/*Joins*/
drop table employee;
CREATE TABLE employee(
	eid INT,
	ename VARCHAR(20),
	emid INT DEFAULT 1, CONSTRAINT pk1111 PRIMARY KEY(eid),
	CONSTRAINT fk1111 FOREIGN KEY(emid) REFERENCES employee(eid) 
	ON DELETE CASCADE 
	ON update CASCADE	
);

/*Without on delete cascade on update cascade*/
drop table employee;

CREATE TABLE employee(
	eid INT,
	ename VARCHAR(20),
	emid INT DEFAULT 1, CONSTRAINT pk1111 PRIMARY KEY(eid),
	CONSTRAINT fk1111 FOREIGN KEY(emid) REFERENCES employee(eid)	
);
select *from employee;

insert into avinash.employee values(1,'avinash',null);
insert into avinash.employee values(2,'b',1);
insert into avinash.employee values(3,'c',1);
insert into avinash.employee values(4,'d',3);
insert into avinash.employee values(5,'e',4);
insert into avinash.employee values(6,'f',5);



delete from employee;

select a.eid as emp_id, a.ename as employees, b.ename as Manager from employee a inner join employee b on a.emid=b.eid;
select a.eid as emp_id, a.ename as employees, b.ename as Manager from employee a left join employee b on a.emid=b.eid;
select a.eid as emp_id, a.ename as employees, b.ename as Manager from employee a right join employee b on a.emid=b.eid;



/*==============================Full join perform required two table===========================*/


DROP TABLE person1;
CREATE TABLE person1
(
	id INT, 
	name VARCHAR(10), CONSTRAINT PRIMARY KEY(id)
);

CREATE TABLE person1address
(
	pid INT,
	city VARCHAR(10), CONSTRAINT pid_fk FOREIGN KEY(pid) REFERENCES person1(id)
	on delete cascade
);

select *from person1;

drop table person1address;
drop table person1;

insert into person1 values(1,'a');
insert into person1address values(1,'banglore');

delete from person1;

 