abstract class X
{
	abstract void test1();
}
class Y extends X
{
	void test1(int i)
	{
	}
}