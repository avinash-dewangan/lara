interface A
{
	void test1();
}
interface B
{
	void test2();
}
abstract class C
{
	abstract void test3();
	void test4()
	{
		System.out.println("from test4");
	}
}
class D extends C implements A, B
{
	public void test1()
	{
		System.out.println("from test1");
	}
	public void test2()
	{
		System.out.println("from test2");
	}
	void test3()
	{
		System.out.println("from test3");
	}
	public static void main(String[] args)
	{
		D d1 = new D();
		d1.test1();
		d1.test2();
		d1.test3();
		d1.test4();
		System.out.println("done");
	}
}