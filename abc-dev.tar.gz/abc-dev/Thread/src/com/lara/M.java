package com.lara;
public class M 
{
	public static void main(String[] args) 
	{
		//System.out.println(1);
		try
		{
			int i = 10;
			System.out.println(i);
		}
		catch (ArithmeticException ex)//Throwable
		{
			System.out.println(ex);
			//System.out.println(i);
			int j = 20;
			System.out.println(j);
		}
		//System.out.println(i);
		
		//System.out.println(j);
	}
}
