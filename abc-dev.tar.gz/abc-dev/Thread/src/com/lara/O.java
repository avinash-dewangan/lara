package com.lara;
public class O 
{
	public static void main(String[] args) 
	{
		System.out.println(1);  //if any ocuuring the exception befor try  then catch is not responsible
		int i = 10/0;
		try
		{
			System.out.println(2);
		}
		catch (ArithmeticException ex)
		{
			System.out.println(3);
		}
		System.out.println(4);
	}
}
