package com.lara;
public class Z 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		try
		{
			System.out.println(1);
			System.exit(0);
			System.out.println(2);
		}
		catch (ArithmeticException ex)
		{
			System.out.println(4);
					}
		finally
		{
			System.out.println(6);
		}
		System.out.println(7);
		
	}
}
