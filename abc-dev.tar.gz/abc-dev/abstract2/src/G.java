interface G
{
	public abstract void test1();
	public abstract void test2();
}