interface L
{
	{
	}
	static
	{
	}
}