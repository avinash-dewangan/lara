class R extends Q
{
}