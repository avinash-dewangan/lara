class G<E>
{
	E e;
	G(E e, int i)
	{
		this.e = e;
	}
}
class Manager6
{
	public static void main(String[] args)
	{
		G<String>g1 = new G<String>("abc",10);
		G<Integer>g2 = new G<Integer>(10,10);
		G<Double>g3 = new G<Double>(10.9,10);
	}
}