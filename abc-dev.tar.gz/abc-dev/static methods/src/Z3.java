class Z3 
{
	static int test1(int i)
	{
		return test2(i++) + test2(++i);
	}
	static int test2(int i)
	{
		return test3(i--) + test3(--i);
	}
	static int test3(int i)
	{
		return i++ + ++i + i;
	}
	public static void main(String[] args) 
	{
		int i;
		i = test1(i = 0);
	//	    0              1
    //  0      -1      1        0
	 
    //  4       1      7        4 = 16 

		System.out.println(i);
		i = test2(i = 0);//
    //      0             -2
	//      4             -2 =2 
		
		System.out.println(i);
		i = test1(i++);// 
	//         2                   3
	//    2       1       3                2
	//    10      7       13             10   =   40
		System.out.println(i);
		i = test2(++i);
	//         41           39
	//     127            121   = 248              
	//
		System.out.println(i);
	}
}
