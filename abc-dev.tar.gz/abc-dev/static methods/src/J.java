class J 
{
	static void test(double a, char b) 
	{
		System.out.println("run the test");
		System.out.println(a);
		System.out.println(b);
	}
	public static void main(String[] args) 
	{
		System.out.println("from main");
		test(90.9090, 'a');
		double v1 = 89.0909;
		char v2 = 's';
		test(v1, v2);
	}
}
