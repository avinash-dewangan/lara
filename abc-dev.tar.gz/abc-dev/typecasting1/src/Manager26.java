class Manager26 
{
	public static void main(String[] args) 
	{
		A a1 = new B();
		B b1 = (B)a1;
		System.out.println("Hello World!");
		A a2 = new A();
		B b2 = (B)a2;
	}
}
