class C extends B  
{
	
}
