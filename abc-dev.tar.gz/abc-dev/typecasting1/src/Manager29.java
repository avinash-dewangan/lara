class Manager29 
{
	public static void main(String[] args) 
	{
		A a1 = new C();
		//System.out.println(a1 instanceof Object);
		System.out.println(a1 instanceof A);
		System.out.println(a1 instanceof B);
		System.out.println(a1 instanceof C);
		System.out.println(a1 instanceof D);
		System.out.println(a1 instanceof String);
		System.out.println("Hello World!");
	}
}
