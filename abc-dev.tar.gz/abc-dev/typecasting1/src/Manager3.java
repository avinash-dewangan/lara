class  
{
	public static void main(String[] args) 
	{
		Object obj1 = null;
		Object obj2 = null;
		obj1 = obj2;
		A a1 = null;
		A a2 = null;
		a1 = a2;

		System.out.println("Hello World!");
	}
}
