class Manager20 
{
	static C test()
	{
		A a1 = new D();
		return a1;
	}
	public static void main(String[] args) 
	{
		D d1 = test();
		System.out.println("Hello World!");
	}
}
