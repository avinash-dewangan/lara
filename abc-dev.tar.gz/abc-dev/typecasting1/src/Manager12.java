class Manager12 
{
	public static void main(String[] args) 
	{
		A a1 = (A) new B();
		A a2 = new B();

		C c1 = new D();
		C c2 = (C) new D();
		System.out.println("Hello World!");
	}
}
