class Manager2  
{
	public static void main(String[] args) 
	{
		Object obj = null;
		A a1 = null;
		B b1 = null;
		C c1 = null;
		D d1 = null;
		obj = new Object;
		a1 = new A();
		b1 = new B();
		c1 = new C();
		d1 = new D();
		System.out.println("done");
	}
}
