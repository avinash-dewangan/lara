package lara;
public class A
{
	int i;
	protected class A
	{
		int i;
		protected int j;
		public int k;
	}
}
class  D extends C
{
	public static void main(String[] args) 
	{
		D d1 = new D();
		System.out.println(d1.i);
	}
}
