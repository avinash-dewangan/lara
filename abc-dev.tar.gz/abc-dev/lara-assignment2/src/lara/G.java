package lara;

class F
{
	void test1()
	{
		system.out.println("test1");
	}
}
class G
{
	public static void main(String[] args) 
	{
		F f1 = new F();
		f1.test1();
		System.out.println("Hello World!");
	}
}
