package pack4;
class A
{
}
class B extends A
{
}
class C extends B
{
}
class D extends C
{
}
class Manager6
{
	public static void main(String[] args)
	{

		A a1  = new C();
		Object o1 = new D();
		B b1 = new C();
		C c1 = new D();
		Object o2 = new D();
		System.out.println("Hello World");
	}
}