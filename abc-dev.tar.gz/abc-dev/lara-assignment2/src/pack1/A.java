package pack1;
class A 
{
	static boolean i;
	public static void main(String[] args) 
	{
		
		System.out.println(i);

	}
}
