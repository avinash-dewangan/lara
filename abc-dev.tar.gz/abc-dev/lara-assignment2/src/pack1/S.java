package pack1;
class S 
{
	S()
	{
		System.out.println("S()");
	}
	S(int i)
	{
		S();  //can not find symbol method S()
		System.out.println("S(int)");
	}
	public static void main(String[] args) 
	{
		S obj1 = new S();
		System.out.println("-----------");
		S obj2 = new S(10);
		System.out.println("-----------");
	}
}
