package pack5;
class S
{
	S()
	{
		System.out.println("S()");
	}
}
class R extends S
{
	R()
	{
		super();
		System.out.println("R()");
	}
}
class T extends R
{
	T()
	{
		super();
		System.out.println("T()");
	}
}
class U 
{
	public static void main(String[] args) 
	{
		T t1 = new T();
		R r1 = new R();
		S s1 = new S();
		System.out.println("Hello World!");
	}
}
