package pack5;
class L 
{
	L()
	{
		super();
		System.out.println("L()");
	}
	L(int i)
	{
		super();
		System.out.println("L(int)");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
