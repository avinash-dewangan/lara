package com.rst;
class C 
{
	public static void main(String[] args) 
	{
		System.out.println("100+20");
		System.out.println("100-20");
		System.out.println("100*20");
		System.out.println("100/20");
		System.out.println("100==2000");
		System.out.println("20==30");
		System.out.println("20!=40");
	}
}
