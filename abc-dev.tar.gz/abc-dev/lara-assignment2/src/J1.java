class J1 
{
	static int i = test();
	static
	{
		System.out.println("sib begin");
		main(null);
		System.out.println("sib end");
	}
	static int test()
	{
		System.out.println("test begin");
		main(null);
		System.out.println("test end");
		return 10;
	}

	public static void main(String[] args) 
	{
		System.out.println("main"+i);
	}
}
