package pack1;
class B
{
	private int i; // 
}
class C 
{
	public static void main(String[] args) 
	{
		B b1 = new B();
		System.out.println(b1.i);// i has private access in B
	}
}
