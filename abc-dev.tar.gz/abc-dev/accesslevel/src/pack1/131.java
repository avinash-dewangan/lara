package pack1;
class O
{
	private O()
	{
		System.out.prinln("O()");
	}
}
class P 
{
	public static void main(String[] args) 
	{
		O o1 = new O(); // O object is not created to inside P
		System.out.println("done");
	}
}
