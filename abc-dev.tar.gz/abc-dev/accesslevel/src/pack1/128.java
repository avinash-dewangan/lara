package pack1;
class J
{
	private int x;
	int y;
}
class K extends J 
{
	public static void main(String[] args) 
	{
		K k1 = new K();
		System.out.println(k1.x);//we can't access because x is private memeber
		System.out.println(k1.y);// x has private access in J
	}
}
//private memeber is not inherited by the sub class;