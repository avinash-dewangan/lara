import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
class A 
{
	void test1()throws SQLException{}
	void test2()throws FileNotFoundException{}
	void test3()throws IOException{}
	void test4()throws NullPointerException{}
	void test5(){}
	
}
public class B extends A                           // overriden means parent class method
												//overrided means child class
{
												//in case of unchecked exception in overriden method then use any unchecked exception in overriding method but in case of checked exception in overriden then use only same as overriden method exception or  child exception in overrdding method 
												// in case of parent hold checked exception then use override child method same checked exception or current checked exception or any unchecked exception
	
	/*
	1						parent unchecked	parent checked				 
			  
	  child unchecked	     ture					true				                  
	  child checked          false					true  
	 
	 
	 1 in case of parent uncheked exception then child keep whether any unchecked exception or doesn't keep any exception.
	 2 in case of parent dosen't keep any exception then child keep whether unchecked exception or doesn't keep any checked exception.
	
	 3	in case of parent checked exception then child keep same as parent exception or his child exception or any unchecked exception or doesn't keep any exception 
	 4	in case of parent doesn't keep any exception then child keep unchecked exception but doesn't keep any checked exception.

	  	
	*/
	
	/*	void test1(){}									
	void test1()throws SQLException{}
	void test1()throws Exception{}
	void test1()throws Throwable{}
	void test1()throws ClassNotFoundException{}
	void test1()throws NumberFormatException{}
	void test2(){}
	void test2()throws FileNotFoundException{}
	void test2()throws IOException{}
	void test2()throws SQLException{}
	void test2()throws Exception{}
	void test2()throws ArithmeticException{}
	void test3(){}
	void test3()throws IOException{}
	void test3()throws FileNotFoundException{}
	void test3()throws ClassNotFoundException{}
	void test3()throws Exception{}
	void test3()throws ClassCastException{}
	void test4(){}
	void test4()throws NullPointerException{}
*/	void test4()throws ArithmeticException{}
/*	void test4()throws ClassNotFoundException{}
	void test5()throws NullPointerException{}
	void test5()throws ClassNotFoundException{}
*/
}
