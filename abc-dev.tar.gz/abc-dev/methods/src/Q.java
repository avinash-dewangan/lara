class Q 
{
	public static void main(String[] args) 
	{
		if(true)
		{
			return;
			System.out.println("Hello world");//unreachable statement
		}
		System.out.println("from end");
	}
}
