class K 
{
	static void test()
	{
		System.out.println("from test");
		System.out.println("from test");
	}
	public static void main(String[] args) 
	{
		test();
		System.out.println("-------");
		test();
		test();
	}
}
