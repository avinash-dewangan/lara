class X 
{
	static int test()
	{
		int i = 10;
		return i;
	}
	public static void main(String[] args) 
	{
		test(); // initilize the variable and return the value of method
		System.out.println(test()); // first initilize then print the retun value of the test method
		System.out.println(test()+test());//
	}
}
