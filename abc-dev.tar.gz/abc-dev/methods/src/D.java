class D 
{
	static void test() //
	{
		System.out.println("test");
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		test();//calling statement
		System.out.println("main end");
	}
}
