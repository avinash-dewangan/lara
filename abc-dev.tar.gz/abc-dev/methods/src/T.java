class T 
{
	static int test()
	{
		System.out.println("from test");
		return 10;
	}
	public static void main(String[] args) 
	{
		int i = test();
		int j = 10 + test();
		System.out.println(test());//10
		System.out.println(i);//10
		System.out.println(j);//20
		System.out.println(i+test());//20
	}
}
