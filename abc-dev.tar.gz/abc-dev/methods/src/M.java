class M 
{
	static void test()
	{
		System.out.println("test begin");
		if(true) ///true value = 0
		{
			System.out.println("from it");
			System.out.println(true);
			System.out.println(false);

			return;
		}
		System.out.println("test end");
	}
	public static void main(String[] args) 
	{
		System.out.println("main begin");
		test();
		System.out.println("main end");
	}
}
