class A 
{
	public static void main(String[] args) 
	{
		int i = 10;
		double d = i;// double d = (double) i;
		//wider   = narrow
		//assignment always right hand side to left side
		//inside the class file only compile cnverting automatic to int to double
		System.out.println("done");
	}
}
