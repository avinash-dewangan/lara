class V 
{
	public static void main(String[] args) 
	{
		double d1 = 10.90;
		long lon = (int) d1;
		System.out.println("done");
	}
}
