class C 
{
	public static void main(String[] args) 
	{
		short i = 20;
		double d = i;//compiler automating converting to short into double

		System.out.println("done");
	}
}
