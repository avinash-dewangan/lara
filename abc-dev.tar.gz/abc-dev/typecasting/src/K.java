class K 
{
	public static void main(String[] args) 
	{
		int i = 10;
		double j = (double) fi;  //explicit wide not required to
		System.out.println("done");
	}
}
