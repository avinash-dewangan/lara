class E  
{
	static void test(double d)
	{
		System.out.println("test(double): " + d);
	}
	public static void main(String[] args) 
	{
		int i = 100;
		test(i);//test((double)i);
		System.out.println("done");
	}
}
