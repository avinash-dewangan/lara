class P 
{
	public static void main(String[] args) 
	{
		
		double d1 = 10.9;
		int i = d1;
		//narrow = wide
		System.out.println("Hello World!");
	}
}
