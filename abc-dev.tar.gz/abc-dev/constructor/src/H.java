class H 
{
	public static void main(String[] args) 
	{
		H h1 = new H();
		System.out.println("done");
	}
}
//if a not any consturctor compile developing in default constructor
//default constructor is no-arg constructor.
