class D 
{
	int i; // i is initilize the constructor body
	int j = 20;//non static initilizer
	D()
	{
		System.out.println("D()");
		i = 10;
	}
	public static void main(String[] args) 
	{
		D d1 = new D();
		System.out.println("------");
		System.out.println(d1.i);
		System.out.println(d1.j);

	}
}
//construtor also non static initilizer