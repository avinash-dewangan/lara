class J 
{
	J()//signature of the constructor
	{
		System.out.println("J()");
	}
	J(int i)
	{
		System.out.println("J(int)");
	}
	public static void main(String[] args) 
	{
		J j1 = new J();
		System.out.println("------");
		J j2 = new J(20);
		System.out.println("------");
		J j3 = new J();
		System.out.println("------");
		J j4 = new J(50);
		System.out.println("------");
	}
}
//inside of a class we can developed any number of constructor
//while developing multiple constructor they should be change in the signature
//developing multiple construtor while choosing difrrent data type of diffrent no of arguments
// is constructor oveloading
//while object is creating by default only one constructor excuting
//getting multiple ways of creating constructor
//totaly two way no-arg or arg