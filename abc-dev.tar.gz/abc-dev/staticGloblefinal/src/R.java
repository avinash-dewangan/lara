abstract class R 
{
	abstract final void test();
}
