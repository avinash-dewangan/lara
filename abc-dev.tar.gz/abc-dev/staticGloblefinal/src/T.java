class T 
{
	static void test1();
}
