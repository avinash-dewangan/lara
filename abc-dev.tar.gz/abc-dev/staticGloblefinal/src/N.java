interface N 
{
	int i;
}
