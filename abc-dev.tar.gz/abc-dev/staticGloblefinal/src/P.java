class P 
{
	final void test1()
	{
	}
	void test2()
	{
	}
}
class Q extends P
{
	void test1()
	{
	}
	void test2(){}
}
