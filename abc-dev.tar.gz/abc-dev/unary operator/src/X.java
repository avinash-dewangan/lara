class X
{
	public static void main(String[] args) 
	{
		int i = 0;
		i = ++i;
		System.out.println(i);
	}
}
