class O 
{
	public static void main(String[] args) 
	{
		int i = 0;
		int j = ++i;//1
		System.out.println(i);//1
		System.out.println(j);//1

	}
}
