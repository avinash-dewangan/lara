abstract class A 
{
	void test1() //considered as define method or implemented method or concrite method because the opening brace and closing brace is body
	{			// test1 method can be used readymade method because having a body or concriteness
	}
	abstract void test2(); // method ending is ; we can treat as just decalre method
	// test2 is a decalred method or undefined method or abstract method
	//this method is no concriteness.
	
}

//method is ending is ; without a body declared as abstract method
	//no defination no concrite
	//method should have either body or abstract keyword
	//a class is containing at least one asbstract method then the class should be asbstract
	//we can not create object of abstract class because not fully developed can not be created object
	//but abstract class we can create a reference variable
	//abstract class is use for database purpose