class C 
{
	abstract void test1();
}

//compile time error