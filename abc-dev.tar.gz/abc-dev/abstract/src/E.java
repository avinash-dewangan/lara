abstract class E 
{
	abstract void test1() //error: abstract method can not have a body
	{
	}
}
