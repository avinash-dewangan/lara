class J 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		int assert = 10;
		System.out.println(assert);
	}
}
//javac -source 1.3