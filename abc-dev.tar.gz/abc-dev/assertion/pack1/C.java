class C 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		assert true;
		System.out.println(2);
	}
}
