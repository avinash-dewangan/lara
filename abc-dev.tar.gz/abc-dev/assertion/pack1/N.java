class N 
{
	public static void main(String[] args) 
	{
		System.out.println(1);
		assert test();
		System.out.println(2);
	}
	static void test()
	{
		System.out.println(3);
	}
}
