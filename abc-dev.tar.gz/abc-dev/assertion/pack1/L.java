class L 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		assert true : ;  //before ; not empty it use value or method
		System.out.println("done");
	}
}
