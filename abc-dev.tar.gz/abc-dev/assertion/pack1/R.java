class Q 
{
	void test() 
	{
		System.out.println(1);
		assert false;
		System.out.println(2);
	}
}
class R
{
	public static void main(String[] args)
	{
		System.out.println("main begin");
		assert false;
		Q q1 = new Q();
		q1.test();
		System.out.println("end main");
	}
}
