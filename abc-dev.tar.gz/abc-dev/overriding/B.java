class A
{
	public void test1()throws Error
	{
		System.out.println("Super class");
		//return 0;
	}
}
public class B extends A
{
	
	public void test1()throws ArithmeticException
	{
		System.out.println("Sub class");
		//return 0;
	}
	public static void main(String[] args) 
	{
		A a = new A();
		A ab = new B();
		B b = new B();
		try{
		a.test1();
		ab.test1();
		b.test1();
		}
		catch(Exception e){}
	}
}
