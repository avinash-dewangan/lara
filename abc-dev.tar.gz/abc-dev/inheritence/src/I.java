class I //inside I.class extends Object class
{
	I()
	{
		//compiler will be keeping super();
		System.out.println("I()");
	}	
}

class J extends I
{
	J()
	{
		//compiler will be keeping super() is calling always
		System.out.println("J()");
	}
}
class K //compiler making K is extends to object class
{
	//compiler will be keeing no arg constructor
	// K(){super()} going to object class the coming back to the K class   this is called constructor chain
	//
	
	public static void main(String[] args)
	{
		I obj1 = new I();
		System.out.println("------");
		J obj2 = new J();
		System.out.println("------");
	}
}
/*/constructor IIB & SIB not inheriting to the sub class
//every class a should have a minimum one constructor
//if does not any constructor providing compiler default constructor

2 every constructor first statement should be either super calling statement or this calling statement.
	
	super();		this();
	suprer(10);		this(20);
	super(20,15);   this(3,4,4);
	super(true);	this('a');
	constructor body first statment super() or this() statement;
	compiler providing super with no-arg
3 ensuring every sub class is object class
   object class in built in class
   for every our which our mandatory object class;
4 in the object class constructor no super class to object class because object class is super most class
*/