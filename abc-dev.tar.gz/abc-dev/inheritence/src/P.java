class P
{
	P()
	{   //super() providing by the compiler
		System.out.println("P()");
	}
}
class Q extends P
{
	Q()
	{
		super(); //providing by the developer
		System.out.println("Q()");
	}
}
class R 
{    //R(){super()} providing by the compiler super is calling object class
	public static void main(String[] args) 
	{
		Q q1 = new Q();                    //output pq..p..
		System.out.println("---");
		P p1 = new P();
		System.out.println("----");
	}
}
