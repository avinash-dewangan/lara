public class C 
{
	int test1()
	{
		try
		{
			
		}
		catch (NullPointerException ex)
		{
		}
		return 20;
	}
	
	int test1(String s1)
	{
		try
		{
			return 1;
		}
		catch (ArithmeticException e)
		{
			return 0;
		}
	}
	
	int test2(String s1)
	{
		try
		{
			
		}
		catch (NumberFormatException e) 
		{
			return 0;
		}
	}
	
	int test3(String s1)
	{
		try
		{
			
		}
		catch (NumberFormatException)
		{
			return 0;
		}
		return 500;
	}
	int test4(String s1)
	{
		try
		{
			return 20;		
		}
		catch (NumberFormatException)
		{
			
		}
	}
	int test5(String s1)
	{
		try
		{
			return 20;
		}
		catch (NumberFormatException)
		{
			
		}
		return 500;
	}
	int test3(String s1)
	{
		try
		{
			return 20;		
		}
		catch (NumberFormatException)
		{
			return 0;
		}
		return 500;
	}
	
}
 