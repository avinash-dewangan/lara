class P 
{
	public static void main(String[] args) 
	{
		try
		{
			test();	
		}
		catch(ClassNotFoundException e)
		{
		}
	}
	static void test()throws ClassNotFoundException
	{
	}
}
