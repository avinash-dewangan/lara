package com.lara;
import java.util.Arrays;
public class W 
{
	public static void main(String[] args) 
	{
		int[] x = {10,20,30,40,4,25};
		int i = Arrays.binarySearch(x,25); 
		System.out.println(i); //-3
		System.out.println("Hello World!");
	}
}
