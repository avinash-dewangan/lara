package com.lara;

public class E 
{
	public static void main(String[] args) 
	{
		int[] x = new int[3];
		System.out.println(x[3]); //Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 3
	}
}

/**
E:\abc-dev\array\app1\src>java -cp ../classes com.lara.E
Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: 3
        at com.lara.E.main(E.java:8)

E:\abc-dev\array\app1\src>
*/