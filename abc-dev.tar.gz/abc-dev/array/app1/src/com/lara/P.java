package com.lara;

public class P 
{
	public static void main(String[] args) 
	{
		int[] x = new int[]{10,2,5,80};
		for (int i = 0;i<x.length ;i++ )
		{
			System.out.println(x[i]);
		}
		System.out.println("Hello World!");
	}
}
