package com.lara;
import java.util.Arrays;
public class S 
{
	public static void main(String[] args) 
	{
		int[] x = {10,20,30,40};
		System.out.println(x);
		System.out.println(Arrays.toString(x));
	}
}
/*
[I@139a55             I is name of class it use to sun developers not programmer
[10, 20, 30, 40]       array class also override static toString method

*/