package com.lara;
public class A
{
	public static void main(String[] args)
	{
		int i = 0;
		System.out.println(i);
		i=10;
		System.out.println(i);
		i=20;
		System.out.println(i);
	}
}