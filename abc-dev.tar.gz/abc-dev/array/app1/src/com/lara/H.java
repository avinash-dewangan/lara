package com.lara;

public class H 
{
	public static void main(String[] args) 
	{
		/**
		* array size should be int only
		* in case byte or shor automatically widening to int type
		  e.g. byte i = 2;
		  int[] a = new a[i]; correct
		* in case float, double type the should do explicity downcasting to int type
		  e.g. double i = 2;
		  int [] a = new a[i]; compile time array not compitable
		  its write  = new a[(int)i];

		* array can't be negative size
		* empty array by deafult value is null
		  e.g. int[] i = new i[]; its empty array allowed
		*/
		int i = 10;
		String[] x = new String[i]; 
		System.out.println("------------");  
		
		i = 0;
		String[] y = new String[i];
		System.out.println("------------");

		i = -2;
		String[] z = new String[i]; 
		/*Exception in thread "main" java.lang.NegativeArraySizeException
        at com.lara.H.main(H.java:30)*/
		System.out.println("------------");

	}
}
