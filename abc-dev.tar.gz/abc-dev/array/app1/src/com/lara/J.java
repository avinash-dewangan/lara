package com.lara;

public class J 
{
	public static void main(String[] args) 
	{
		int[] x = new int[2];
		int[] y = x;             // x and y is point same array        
		x[0]= 10;
		y[0]= 20;
		System.out.println(x[1]); //0 is intilize value
		System.out.println(y[0]); //20 is modified value
	}
}
