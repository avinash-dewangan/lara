package com.lara;

public class C 
{
	public static void main(String[] args) 
	{
		int[] x;  //first declaration
		x = new int[3]; //the creating array size;
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);
		x[0]=100;
		x[1]=200;
		x[2]=300;
		System.out.println(x[0]);
		System.out.println(x[1]);
		System.out.println(x[2]);

		System.out.println("Hello World!");
	}
}
