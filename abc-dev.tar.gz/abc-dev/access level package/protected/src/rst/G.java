package rst;
class G extends lara.A 
{
	public static void main(String[] args) 
	{
		lara.A a1 = new lara.A();
		//System.out.println(a1.i);
		//System.out.println(a1.j);
		System.out.println(a1.k);
		G g1 = new G();
		//System.out.println(g1.i);
		System.out.println(g1.j);
		System.out.println(g1.k);
	}
}
