package rst;
class H extends G 
{
	public static void main(String[] args) 
	{
		H h1 = new H();
		System.out.println(h1.j);
		System.out.println(h1.k);
	}
}
