package rst;
class L extends I 
{
	public static void main(String[] args) 
	{
		L obj1 = new L();
		System.out.println(obj1.j);
		System.out.println(obj1.k);
		I obj2 = new I();
		System.out.println(obj2.j);
		System.out.println(obj2.k);

	}
}
