package rst;
class L  
{
	public static void main(String[] args) 
	{
		lara.A a1 = new lara.A();
		System.out.println(a1.i);
	}
}
//default class can access only same package in the class