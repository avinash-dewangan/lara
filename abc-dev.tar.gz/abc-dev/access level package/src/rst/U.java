package rst;
class U extends lara.N 
{
	public static void main(String[] args) 
	{
		lara.N n1 = new lara.N();
		lara.N n2 = new lara.N();
		lara.N n3 = new lara.N();
		System.out.println("done");
	}
}
