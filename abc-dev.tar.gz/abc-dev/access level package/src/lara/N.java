package lara;
public class N  //N class is public it is used to outside of the package
{
	int i; //i is default its not use the outside of the package
}
