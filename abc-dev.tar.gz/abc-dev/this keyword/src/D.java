class D 
{
	int i;
	public static void main(String[] args) 
	{
		D d1 = new D();
		System.out.println(d1.i);
	}
}
