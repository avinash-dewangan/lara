/**
* static member is use any where in current class.
* we can use also other class if aaccess specifier is allowd.
* Static member(static variable) is use any where like IIB, SIB, Constructor, non-static mehtod, static mentod,main method
*/
class B
{
	static int i;
	B()
	{
		i=10;//B.i=10;
	}

	{
		i=20;
	}

	static
	{
		i = 30;
	}

	void test()
	{
		i=40;

	}

	public static void main(String[] args)
	{
		System.out.println(i);
		i=50;
		System.out.println(i);
	}
}