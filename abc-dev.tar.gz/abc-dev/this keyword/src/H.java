class H 
{
	void test()
	{
		System.out.println("test:"+this);
	}
	public static void main(String[] args) 
	{
		H h1 = new H();
		System.out.println("main:"+h1);
		h1.test();
	}
}
/*

E:\abc-dev\this keyword\src>javac -d ../classes H.java

E:\abc-dev\this keyword\src>java -cp ../classes H
main:H@139a55
test:H@139a55

E:\abc-dev\this keyword\src>

*/