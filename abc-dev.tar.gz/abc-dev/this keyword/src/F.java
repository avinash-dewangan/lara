class F 
{
	int i;
	F()
	{
		i = 10;
	}
	public static void main(String[] args) 
	{
		System.out.println("");
	}
}
