package hello;
abstract class Samsung
{
	void model()
	{
	}
}
