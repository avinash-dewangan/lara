package demo;
class Demo
{
	public int myMethod(int num1, int num2)
	{
		System.out.println("first myMethod of class Demo");
		return num1+num2;
	}
	public int myMethod(int var1, int var2)
	{
		System.out.println("first myMethod of class Demo");
		return num1-num2;
	}
}

class Sample4 
{
	public static void main(String[] args) 
	{
		Demo obj1 = new Demo();
		obj1.myMethod(10,10);
		obj1.myMethod(20,12);
		//System.out.println("Hello World!");
	}
}
