package vehicle;
class TwoWheeler
{
}
class Bike 
{
}
class Honda extends TwoWheeler, Bike
{
}
//compile time error 