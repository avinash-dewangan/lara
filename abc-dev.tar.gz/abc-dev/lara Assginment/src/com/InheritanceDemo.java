package com;
class Person
{
	String FirstName;
	String LastName;
	Person(String fName, String lName)
	{
		FirstName = fName;
		LastName = lName;
	}
	void Display()
	{
		System.out.println("First Name "+FirstName);
		System.out.println("Last Name "+LastName);
	}
}
class Student extends Person
{
	int id;
	String standard;
	String instructor;
	Student(String fName, String lName, int nid, String stnd, String instr)
	{
		super(fName, lName);
		id = nid;
		standard = stnd;
		instructor = instr;
	}
	void Display()
	{
		super.Display();
		System.out.println("ID: "+id);
		System.out.println("Standard: "+standard);
		System.out.println("instructor: "+instructor);
	}
}
class Teacher extends Person
{
	String mainSubject;
	int salary;
	String type;
	Teacher(String fName, String lName, String sub, int slry, String sType)
	{
		super(fName, lName);
		mainSubject = sub;
		salary = slry;
		type =sType;
	}
	void Display()
	{
		super.Display();
		System.out.println("MainSubject "+mainSubject);
		System.out.println("Salary "+salary);
		System.out.println("Type "+type);
	}
}
class InheritanceDemo
{
	public static void main(String args[])
	{
		Person p1 = new Person("jaya","Ram");
		Student s1 = new Student("Vishal","Babu",1,"1-B","Sreekanth");
		Teacher t1 = new Teacher("Ganesh", "Babu","English",12000,"Primary Teacher");
		System.out.println("Person :");
		p1.Display();
		System.out.println("");

		System.out.println("Student :");
		s1.Display();
		System.out.println("");

		System.out.println("Teacher :");
		t1.Display();
	}
}