package com.pack2;
class A
{
	A(int x, int y)
	{
		int sum = x+y;
		System.out.println("sum is"+sum);
	}
}
public class B extends A 
{
	B()
	{
		super(1,2);
	}
	void calculate(int x, int y)
	{
		int product = x*y;
		System.out.println("product is:"+product);
	}
	public static void main(String[] args) 
	{
		B b = new B();
		b.calculate(5,4);
		//System.out.println("Hello World!");
	}
}
