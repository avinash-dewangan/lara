package com.pack1;
class H
{
	int id;
	double marks;
	void student(int id)
	{
		id = 2;
		System.out.println("Student id "+id);
	}
	void student(double marks)
	{
		marks = 85.0;
		System.out.println("Student marks "+marks);

	}
	public static void main(String[] args)
	{
		H h1 = new H();
		h1.student(12);
		h1.student(68.6);
	}
}