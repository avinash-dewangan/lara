package com.lara;
interface Moveable
{
	void moveFast();
}
class Crawlable implements Moveable
{
	public void moveFast()
	{
		System.out.println("Rabbit:i am moving fas, buddy!!");
	}
	public void craw()
	{
		System.out.println("Tortoise:i am moving slowly!!");
	}
}
public class Animal extends Crawlable implements Moveable
{
	public static void main(String[] args)
	{
		Animal self = new Animal();
		self.moveFast();
		self.craw();
	}
}