package com.lara;
class ABC
{
	public void mymethod()
	{
		System.out.println("class ABC:mymethod");
	}
}
class Test extends ABC
{
	public void mymethod()
	{
		super.mymethod();
		System.out.println("class Test:mymethod");
	}
	public static void main(String[] args) 
	{
		Test obj = new Test();
		obj.mymethod();
		//System.out.println("Hello World!");
	}
}
