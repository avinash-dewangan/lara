package com.lara;
class A
{
	abstract void test();
}
/*
E:\abc-dev\lara\src>javac -d ../classes com/lara/A.java
com\lara\A.java:2: error: A is not abstract and does not override abstract metho
d test() in A
class A
^
1 error

E:\abc-dev\lara\src>
*/