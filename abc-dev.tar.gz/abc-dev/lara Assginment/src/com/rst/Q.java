package com.rst;
interface Area
{
	float compute(float x, float y);
}
class Rectangle implements Area
{
	public float compute(float x, float y)
	{
		return(x*y);
	}
}
class Triangle implements Area
{
	public float compute(float x, float y)
	{
		return(x*y/2);
	}
}
class Q
{
	public static void main(String arg[])
	{
		Rectangle rect = new Rectangle();
		Triangle tri = new Triangle();
		System.out.println("Area of Rectangle="+rect.compute(5,9)+"mtrs");
		System.out.println("Area of Triangle="+tri.compute(12,12)+"mtrs");

	}
}