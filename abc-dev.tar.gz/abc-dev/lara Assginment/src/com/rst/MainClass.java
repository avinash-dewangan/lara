package com.rst;
class MyClass
{
	int height;
	MyClass()
	{
		System.out.println("bricks");
		height = 0;
	}
	MyClass(int i)
	{
		System.out.println("Building new House that is "+i+" feet tall");
		height= i;
	}
	void info()
	{
		System.out.println("Home is "+height+" feet tall");
	}
	void info(String s)
	{
		System.out.println(s+" Home is "+height+" feet tall");
	}
}
public class MainClass
{
	public static void main(String[] args) 
	{
		MyClass t = new MyClass(12);
		t.info();
		t.info("overloaded method");
		//System.out.println("Hello World!");
	}
}
