package lara.rst;
interface Person
{
	public void eat();
	public void travel();
}
class Ramu implements Person
{
	public void eat()
	{
		System.out.println("Ramu is eating");
	}
	public void travel()
	{
		System.out.println("Ramu is travelling");
	}
	public int noOfCars()
	{
		return 2;
	}
	public static void main(String[] args) 
	{
		Ramu d1 = new Ramu();
		d1.eat();
		d1.travel();
		d1.noOfCars();
		System.out.println("Ramu has "+d1.noOfCars()+" Cars");
	}
}
