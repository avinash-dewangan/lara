package lara;
class Square
{
	int height;
	int width;
	Square()
	{
		height = 12;
		width = 5;
	}
	Square(int side)
	{
		height = width=side;
	}
	Square(int sideh, int sidew)
	{
		height = sideh;
		width = sidew;
	}
}
class SquareImpl 
{
	public static void main(String[] args) 
	{
		Square obj1 = new Square();
		Square obj2 = new Square(5);
		Square obj3 = new Square(2,3);

		System.out.println("Variable value of Object1");
		System.out.println("Object1 height = "+obj1.height+"mtrs");
		System.out.println("Object1 height = "+obj1.width+"mtrs");
		System.out.println(" ");
		
		System.out.println("Variable value of Object2");
		System.out.println("Object2 height = "+obj2.height+"mtrs");
		System.out.println("Object2 height = "+obj2.width+"mtrs");
		System.out.println(" ");

		System.out.println("Variable value of Object2");
		System.out.println("Object3 height = "+obj3.height+"mtrs");
		System.out.println("Object3 height = "+obj3.width+"mtrs");
		System.out.println(" ");

	}
}
