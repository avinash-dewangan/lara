package person;
class Human
{
	String s1, s2;
	public Human()
	{
		s1 = "Super class";
		s2 = "Parent class";
	}
	public Human(String str)
	{
		s1 = str;
		s2 = str;
	}
}
class Boy extends Human 
{
	public Boy()
	{
		s2 = "child class";
	}
	public void disp()
	{
		System.out.println("String1 is :"+s1);
		System.out.println("String2 is :"+s2);
	}
	public static void main(String[] args) 
	{
		Boy obj = new Boy();
			obj.disp();
		//System.out.println("Hello World!");
	}
}
