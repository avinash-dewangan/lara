class K 
{
	public static void main(String[] args) 
	{
		byte i = 6;
		switch(i)
		{
			case 127: 
		System.out.println("Hello World!");
			case 126:
		System.out.println("dHello World!");
			default:
				System.out.println("djfls");
			case 125:
		System.out.println("dHello Worlddfdsfsdfsd!");
		}
		System.out.println("dHello Worlddfds!");
		
	}
}
