
class DoubleTon
{
	private static DoubleTon[] tons = new DoubleTon[5];
	private static int index;
	private DoubleTon()
	{
		System.out.println("DoubleTon()");
	}
	static
	{
		tons[0] = new DoubleTon();
		tons[1] = new DoubleTon();
		tons[2] = new DoubleTon();
		tons[3] = new DoubleTon();
		tons[4] = new DoubleTon();
	}
	public static DoubleTon getObject()
	{
		return tons[(index++)%5];
	}
}

class DoubleTonTest
{
	public static void main(String[] args)
	{
		DoubleTon dt = DoubleTon.getObject();
		DoubleTon dt1 = DoubleTon.getObject();
		DoubleTon dt2 = DoubleTon.getObject();
		DoubleTon dt3 = DoubleTon.getObject();
		DoubleTon dt4 = DoubleTon.getObject();
		DoubleTon dt5 = DoubleTon.getObject();
		DoubleTon dt6 = DoubleTon.getObject();
		System.out.println(dt);
		System.out.println(dt1);
		System.out.println(dt2);
		System.out.println(dt3);
		System.out.println(dt4);
		System.out.println(dt5);
		System.out.println(dt6);

	}
}

