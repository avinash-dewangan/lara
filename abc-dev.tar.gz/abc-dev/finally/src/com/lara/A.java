package com.lara;
class A 
{
	int test1(boolean flag)
	{
		return 1000;
	}
	int test2(boolean flag)
	{
		if(flag)
		{
			return 10;
		}
		else
		{
			return 20;
		}
	}
	/*int test3(boolean flag)
	{
		if(flag)
		{
			return 10;
		}
	}*/
	int test4(boolean flag)
	{
		if(flag)
		{
			
		}
		return 20;
	}
	/*int test5(boolean flag)
	{
		if(flag)
		{
			
		}
		else
		{
			return 20;
		}
	}*/
	int test6(boolean flag)
	{
		if(flag)
		{
			
		}
		else
		{
			return 20;
		}
		return 0;
	}
	/*int test7(boolean flag)
	{
		if(flag)
		{
			return 200;
		}
		else
		{
			return 20;
		}
		return 0;
	}*/
}
