class C 
{
	int i;
	static void test() 
	{
		System.out.println(i);//compile time error because not static
	}
}
