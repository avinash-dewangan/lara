class G 
{
	int i;
	public static void main(String[] args) 
	{
		G g1 = new G();
	  //left    right
     // left hand reference creation 
	 //right side is a object creation
	//  g1 is refrence     
	//  new G() is object cration
		System.out.println(g1.i);
	}
}
