class E 
{
	int i
	static
	{
		System.out.println(i);//non static member used in the static block. compile time error
	}
}
