class I 
{
	int x;
	static void test1()
	{
		I rv = new I();
		System.out.println(rv.x); //rv assign to x variable
	}
}
