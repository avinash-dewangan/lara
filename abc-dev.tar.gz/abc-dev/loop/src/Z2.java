class Z2 
{
	public static void main(String[] args) 
	{
		for (int i = 0;i<10 ;i++ )
		{
			System.out.println(i);
			int j = 10/0;
		}
		System.out.println("end");
		
	}
}
