class P 
{
	public static void main(String[] args) 
	{
		for (double i=0.0;i<20.0;i=i+5)
		{
			System.out.println("done");
		}
		
	}
}
