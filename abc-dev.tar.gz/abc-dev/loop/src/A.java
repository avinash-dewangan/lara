class A 
{
	public static void main(String[] args) 
	{
		
		for(int i = 0,j = 20; i<5||j>18; i++, j--)
		{
			System.out.println(i+","+j);
		}
		//System.out.println(i);
		
	}
}
