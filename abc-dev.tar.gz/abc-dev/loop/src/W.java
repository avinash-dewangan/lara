class W 
{
	public static void main(String[] args) 
	{
		int i =0;
		for (i=1;i<10;i++ )
		{
		
			continue;
			//System.out.println(i);
		}
		System.out.println(i);
		
	}
}
