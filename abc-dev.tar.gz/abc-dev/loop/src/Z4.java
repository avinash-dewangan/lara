class Z4 
{
	public static void main(String[] args) 
	{
		String []x = {"abc","xyz","hello","ram"};
		for(String s1:x)//for each
		{
			System.out.println(s1);
		}
	}
}
