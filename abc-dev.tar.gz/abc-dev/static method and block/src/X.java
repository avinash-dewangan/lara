class X 
{
	static
	{
		static int i = 10;//in defination class compile time error
		int j = 10;
		System.out.prinltn("Hello World");
	}
}
