class Z 
{
	static
	{
		static void test()//method always should be a member of the class
		{
		}
	}
}
