enum B
{

}
class C
{
}
interface D
{
	public static void main(String[] args){
		System.out.println("dsjf");
	}
}