class R 
{
	static int i = 10;
}
