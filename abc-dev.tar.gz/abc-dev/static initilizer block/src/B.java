class B
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
	static  //static initiliztion block
	{
		System.out.println("from SIB"); 
	}

}
