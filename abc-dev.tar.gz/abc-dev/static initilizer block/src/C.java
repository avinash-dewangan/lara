class C
{
	
	static  //static initiliztion block
	{
		System.out.println("SIB1"); 
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
	static  //static initiliztion block
	{
		System.out.println("SIB2"); 
	}

}
//every initilizer excuting before main method from top to bottom