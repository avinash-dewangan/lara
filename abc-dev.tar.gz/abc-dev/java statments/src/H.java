class H 
{
	public static void main(String[] args) 
	{
		int i, j, k=10, m;
		i = 20;
		j = i + 30;
		m = j + k + 20;

		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
		System.out.println(m);

	}
}
