class Y 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello");
		System.out.println("Lara");
		System.out.println("Rst");

		System.out.print("Hello");
		System.out.print("Lara");
		System.out.print("Rst");

	}
}
