class S 
{
	public static void main(String[] args) 
	{
		int i;
		i++; // i= i+1; var i might not have been initilized
		System.out.println(i);
	}
}
