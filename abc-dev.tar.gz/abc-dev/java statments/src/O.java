class O 
{
	public static void main(String[] args) 
	{
		int i;   //if you not using local variable there is no compile error
		System.out.println("done");
	}
}
