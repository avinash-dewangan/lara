class B
{
	public static void main(String[] args)
	{
		System.out.println("Hello World");
		System.out.println(1000);
		System.out.println(10.900);
		System.out.println(true);
		System.out.println('a');
		System.out.println("Hello World");
	}
}