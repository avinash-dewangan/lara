class K 
{
	public static void main(String[] args) 
	{
		int i, j, m;
		double n;
		i = j = m = 10;
		n = 30.90;
		
		System.out.println(i);
		System.out.println(j);
		System.out.println(m);
		System.out.println(n);
	}
}
