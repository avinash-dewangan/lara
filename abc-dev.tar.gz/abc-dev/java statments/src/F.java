class F
{
	public static void main(String[] args) 
	{
		int i;
		i=20;
		System.out.println(i);
	}
}
