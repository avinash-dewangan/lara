class Q
{
	public static void main(String[] args) 
	{
		int i;
		int j = i;
		System.out.println(i); //without initilization i variable is not using
		System.out.println(j);
	}
}
