class D
{
	public static void main(String[] args)
	{
		int i=10;
		System.out.println(i);
		int i=20;
		System.out.println(i);
		
		
	}
}