class A
{
	A(int i)
	{
		//super();
		System.out.println("Y(int)");
	}
}
class B extends A
{
	B()
	{
		System.out.println("B()");
	}
	public static void main(String[] args) 
	{
		A a1 = new A(10);
		System.out.println("------");
		B b1 = new B();
	}
}
