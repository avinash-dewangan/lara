class M
{
	M(int i)
	{
		System.out.println("M(int)");
	}
	{
		System.out.println("M-IIB");
	}
	M(int i, int j)
	{
		this(j);
		System.out.println("M(int,int)");
	}
}
class N extends M 
{
	N()
	{
		System.out.println("N()");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
