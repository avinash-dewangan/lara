package com.lara;
class K
{
	int i =10;
}

public class Manager11 
{
	public static void main(String[] args) 
	{
		K k1 = new K();
		K k2 = new K();
		System.out.println(k1==k2); //just beacuse ref is pointing to the different object
	}
}
