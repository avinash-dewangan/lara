package com.lara;
class D
{
}
public class Manager4
{
	public static void main(String[] args) 
	{
		D d1 = new D();
		D d2 = d1;

		System.out.println(d1);
		System.out.println(d2);

	}
}
