package com.rst;

class W
{
	int i;
	String j;
	char k;
	boolean m;
	W(int i, String j, char k, boolean m)
	{
		this.i=i;
		this.j=j;
		this.k=k;
		this.m=m;
	}
	public int hashCode()
	{
		String s1 = Integer.toString(i);
		String s2 = Character.toString(k);
		String s3 = Boolean.toString(m);
		int hash = s1.hashCode();
		hash += s2.hashCode();
		hash +=s3.hashCode();
		hash +=j.hashCode();
		return hash;
	}
}
public class Manager14
{
	public static void main(String[] args) 
	{
		W w1 = new W(10,"abc",'p',true);
		W w2 = new W(10,"abc",'p',true);
		System.out.println(w1.hashCode());
		System.out.println(w2.hashCode());  //ref is different but hash code is same this is not accurate
	}
}
