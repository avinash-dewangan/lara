package com.lara;
import java.util.ArrayList;
import java.util.Collections;

class C 
{
	int i;
	C(int i)
	{
		this.i=i;
	}
	public String toString()
	{
		//return "i" + i;
		return "" + i;
		//return i; //int can not be converted to String return i
	}
	
}
public class Manager23
{
	public static void main(String[] args)
	{
		ArrayList list = new ArrayList();
		list.add(new C(10));
		list.add(new C(3));
		list.add(new C(9));
		list.add(new C(5));
		System.out.println(list);
		Collections.sort(list);
		System.out.println(list);
	}
}
/*
[10, 3, 9, 5]
Exception in thread "main" java.lang.ClassCastException: com.lara.C cannot be cast to java.lang.Comparable
        at java.util.ComparableTimSort.countRunAndMakeAscending(ComparableTimSort.java:320)
        at java.util.ComparableTimSort.sort(ComparableTimSort.java:188)
        at java.util.Arrays.sort(Arrays.java:1312)
        at java.util.Arrays.sort(Arrays.java:1506)
        at java.util.ArrayList.sort(ArrayList.java:1454)
        at java.util.Collections.sort(Collections.java:141)
        at com.lara.Manager23.main(Manager23.java:30)

*/