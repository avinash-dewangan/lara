package com.lara;
import java.util.ArrayList;
public class Manager13 
{
	public static void main(String[] args) 
	{
		ArrayList list1 = new ArrayList();
		list1.add(9);
		list1.add(0);
		list1.add(4);
		list1.add(6);
		list1.add(8);
		list1.add(2);
		list1.add(1);
		list1.add(3);
		ArrayList list2 = new ArrayList();
		list2.add(5);
		list2.add(4);
		list2.add(2);
		list2.add(8);
		System.out.println(list1); //[9,0,4,6,8,2,1,3]
		System.out.println(list2); //[5,4,2,8]			
		System.out.println("********");
		list1.retainAll(list2);  //retainAll is opposit of removeAll delete list1 all element except list2 match element
		System.out.println(list1);//[9,0,6,2,1,3]
		System.out.println(list2);//[5,4,2,8]

 	}
}
