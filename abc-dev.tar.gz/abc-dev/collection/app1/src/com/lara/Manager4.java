package com.lara;
import java.util.ArrayList;
public class Manager4 
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();
		list.add(90);
		list.add(9.9);
		list.add("abc");
		list.add(true);
		System.out.println(list);
		System.out.println("***normal for loop output***");
		for(int i=0;i<list.size();i++)
		{
			System.out.println(list.get(i)+",");
		}
		System.out.println("***for each loop output***");
		for (Object obj : list)
		{
			System.out.println(obj+",");
		}

	}
}
