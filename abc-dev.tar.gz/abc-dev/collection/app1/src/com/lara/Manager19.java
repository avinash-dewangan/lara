package com.lara;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
public class Manager19 
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();
		list.add(8.9);
		list.add(9);
		list.add(9.0);
		list.add(9.1);
		System.out.println(list);
		Collections.sort(list);     
		System.out.println(list);
	}
}

/*
E:\abc-dev\collection\app1\src>java -cp ../classes com.lara.Manager19
[8.9, 9, 9.0, 9.1]
Exception in thread "main" java.lang.ClassCastException: java.lang.Double cannot
 be cast to java.lang.Integer
        at java.lang.Integer.compareTo(Integer.java:52)
        at java.util.ComparableTimSort.countRunAndMakeAscending(ComparableTimSor
t.java:320)
        at java.util.ComparableTimSort.sort(ComparableTimSort.java:188)
        at java.util.Arrays.sort(Arrays.java:1312)
        at java.util.Arrays.sort(Arrays.java:1506)
        at java.util.ArrayList.sort(ArrayList.java:1454)
        at java.util.Collections.sort(Collections.java:141)
        at com.lara.Manager19.main(Manager19.java:15)

*/