package com.lara;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
public class Manager20 
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();
		list.add("abc");
		list.add("ABC");
		list.add("aBC");
		list.add("ABc");
		list.add("AbC");
		list.add("123");
		System.out.println(list);
		Collections.sort(list);     
		System.out.println(list);
	}
}

