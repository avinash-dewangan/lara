package com.lara;
import java.util.ArrayList;
public class Manager2
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();
		list.add(90);
		list.add(true);
		int i = (Integer)list.get(0); //0 is index not a value
		boolean flag = (Boolean)list.get(1); //1 is index not a value get method passing the index
		System.out.println(i);
		System.out.println(flag);
	}
}
