class U 
{
	static int i = j; //illegal forward references
	static int j = 10;
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
	}
}
