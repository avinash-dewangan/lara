//no compilation error
// no generating the class file because class is not there
//this is empty java file