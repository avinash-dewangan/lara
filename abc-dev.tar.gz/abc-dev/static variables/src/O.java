class O 
{
	static int i;
	public static void main(String[] args) 
	{
		System.out.println(O.i); //0 
		O.i = 10;
		System.out.println(O.i); // 10
	}
}
