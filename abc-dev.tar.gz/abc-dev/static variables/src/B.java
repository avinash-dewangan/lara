class B 
{
	static int i; // 0 is default value
	static double j; // 0.0 is default value
	static boolean k; // false is default value
	public static void main(String[] args) 
	{
		System.out.println(i);
		System.out.println(j);
		System.out.println(k);
	}
}
