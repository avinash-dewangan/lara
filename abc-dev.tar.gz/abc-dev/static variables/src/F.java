class F 
{
	static int i, j = 10, k, m = 20; 
	public static void main(String[] args)      // all together five members 4 globle variable & 1 main method 
	{
		System.out.println(i);//0
		System.out.println(j);//10
		System.out.println(k);//0
		System.out.println(m);//20

	}
}
