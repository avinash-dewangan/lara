class Q 
{
	static int i = 10;
	public static void main(String[] args) 
	{
		System.out.println(i);//10
		double i = 2.9;
		System.out.println(i);//2.9
		System.out.println(Q.i);//10
	}
}
