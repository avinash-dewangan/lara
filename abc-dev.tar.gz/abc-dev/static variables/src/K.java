class K 
{
	static int i;
	public static void main(String[] args) //same name choosed for globle & local
	{
		System.out.println("a:" + i);//0 i is accessing globle var
		int i = 10;
		System.out.println("b:" + i);//10 i is accessing local var
		i = 20;
		System.out.println("c:" + i);//20 i is accessing modify local var
	}
}
