class M 
{
	static int i = 10;
	static boolean i = true; // same name of two variable in same scope
	public static void main(String[] args) 
	{
		System.out.println("done");
	}
}
