package com.app3;
class H 
{
	public static void main(String[] args) 
	{
		StringBuffer sb = new StringBuffer();		
		System.out.println(sb.capacity());//16
		sb.append("abc");
		sb.append("abc");
		sb.trimToSize();
		System.out.println(sb.capacity());
		System.out.println(sb.length());
	}
}