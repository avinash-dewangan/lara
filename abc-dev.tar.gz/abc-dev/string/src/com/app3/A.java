package com.app3;
class A 
{
	public static void main(String[] args) 
	{
		String s1 = "java";
		String s2 = "ja";
		String s3 = s2+"va"; //s3 is create new object. in case of ref+constant then create new object heap memory
		System.out.println(s1==s3);//false just because of s1 and s3 have not pointing the same object
		System.out.println(s3);
		System.out.println(s1.equals(s3));
		System.out.println(s1.hashCode());
		System.out.println(s3.hashCode());

	}
}
