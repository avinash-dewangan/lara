package com.app3;
class N
{
	public static void main(String[] args) 
	{
		StringBuilder sb = new StringBuilder();		
		sb.append("hello");
		//sb.deleteCharAt(6);
		System.out.println(sb);
		System.out.println(sb.capacity());
		System.out.println(sb.length());
	}
}