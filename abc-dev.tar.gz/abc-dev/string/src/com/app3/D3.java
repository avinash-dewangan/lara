package com.app3;
class D3 
{
	public static void main(String[] args) 
	{
		String s1 = "abc hello";
		char[] x = s1.toCharArray();   //convert String object to character array
		for(int i =0; i<x.length; i++)
		{
			System.out.println(x[i]+", ");
	
		}
	}
}