package com.app3;
class C 
{
	public static void main(String[] args) 
	{
		String s1 = "java";
		String s2 = "ja";
		String s3 = s2.concat("va");// creating object inside heap area with s3 reference
		System.out.println(s1==s3);//false;

	}
}
