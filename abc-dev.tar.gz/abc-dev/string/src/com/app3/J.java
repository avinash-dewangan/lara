package com.app3;
class J 
{
	public static void main(String[] args) 
	{
		StringBuffer sb = new StringBuffer();		
		sb.append("hello");
		sb.reverse();
		System.out.println(sb);
	}
}