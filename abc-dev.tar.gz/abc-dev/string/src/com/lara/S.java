package com.lara;
class S 
{
	public static void main(String[] args) 
	{
		String s1 = "hello to all"; 
		System.out.println(s1.startsWith("hello"));
		System.out.println(s1.startsWith("all"));
		System.out.println(s1.endsWith("hello"));
		System.out.println(s1.endsWith("all"));
	}
}