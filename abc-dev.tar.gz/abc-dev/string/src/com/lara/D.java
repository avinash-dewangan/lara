package com.lara;
class D 
{
	public static void main(String[] args) 
	{
		String s1 = "abc abc abc";
		int i = s1.indexOf("abc");
		System.out.println(i);//0

		int j = s1.indexOf("abc", 2);//4
		System.out.println(j);

		int k = s1.indexOf("abc", 6);//8
		System.out.println(k);

	}
}
