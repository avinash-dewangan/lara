package com.lara;
class J 
{
	public static void main(String[] args) 
	{
		String s1 = "lara tech";
		//           012345678  
		int i = s1.indexOf(' ');
		String s2 = s1.substring(0,i);
		                        // 0 , 4
		String s3 = s1.substring(i+1, s1.length());
								//5, 9 
		System.out.println(s2); //lara
		System.out.println(s3);// tech
		System.out.println(s1.length());
	}
}
