package com.lara;
import java.util.*;
class N 
{
	public static void main(String[] args) 
	{
		String s1 = "abc xyz hello 123";
		String[] x = s1.split(" ");
		System.out.println(Arrays.toString(x));
		for(String str:x)
		{
			System.out.println(str);
		}
	}
}
