package com.lara;
class H 
{
	public static void main(String[] args) 
	{
		String s1 = "abc abc abc abc";
				//   01234567891011121314
		int i = s1.lastIndexOf("abc");

		System.out.println(i);//12

		int j = s1.lastIndexOf("abc",5);

		System.out.println(j);//4

		int k = s1.lastIndexOf("abc",9);

		System.out.println(k);//8
	}
}
