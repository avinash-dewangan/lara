package com.lara;
class O 
{
	public static void main(String[] args) 
	{
		String s1 = "abc xyz";
		System.out.println(s1.toUpperCase());
		System.out.println(s1);
	}
}
