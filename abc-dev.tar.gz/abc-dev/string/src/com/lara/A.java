package com.lara;
class A 
{
	public static void main(String[] args) 
	{
		String s1 = "hello 123";
		int i = s1.indexOf('e');

		System.out.println(i);
		int j = s1.indexOf('2');
		System.out.println(j);

		int k = s1.indexOf('z');
		System.out.println(k);
	}
}
