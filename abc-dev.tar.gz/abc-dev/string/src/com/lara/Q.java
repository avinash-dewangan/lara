package com.lara;
class Q 
{
	public static void main(String[] args) 
	{
		String s1 = "ABC XYZ abc";
		s1 = s1.toLowerCase();
		System.out.println(s1);
	}
}
