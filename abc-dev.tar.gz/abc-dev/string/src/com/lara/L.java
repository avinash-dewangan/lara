package com.lara;
class L 
{
	public static void main(String[] args) 
	{
		String s1 = "laratech";
		String s2 = s1.substring(5, 20);
		System.out.println(s2);
	}
}

/*

E:\abc-dev\string\src>java -cp ../classes com.lara.L
Exception in thread "main" java.lang.StringIndexOutOfBoundsException: String index out of range: 20
        at java.lang.String.substring(String.java:1963)
        at com.lara.L.main(L.java:7)

E:\abc-dev\string\src>

**/