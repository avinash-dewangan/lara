package com.rst;
class J2 
{
	public static void main(String[] args) 
	{
		String s1 = NULL;
		System.out.println(s1);
	}
}
/**
its not literal not varaible not data type
E:\abc-dev\string>javac J2.java
J2.java:5: error: cannot find symbol
                String s1 = NULL;
                            ^
  symbol:   variable NULL
  location: class J2
1 error

*/