package com.rst;
class M 
{
	public static void main(String[] args) 
	{
		
		System.out.println("lara"+5);
		System.out.println(2+"lara"+5);
		System.out.println(10+"abc"+null);
		System.out.println(10+20+"abc");
		System.out.println("lara"+10+20);
	}
}
