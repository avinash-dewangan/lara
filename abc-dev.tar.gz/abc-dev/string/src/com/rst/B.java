package com.rst;
class B 
{
	public static void main(String[] args) 
	{
		String s1 ="hello";
		System.out.println(s1);
		System.out.println(s1.length());


	}
}
