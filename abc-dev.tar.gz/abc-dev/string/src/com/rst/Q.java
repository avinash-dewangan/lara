package com.rst;
class Q 
{
	public static void main(String[] args) 
	{
		String s1 = " abc xyz ";
		System.out.println(s1.length());
		String s2 =s1.trim();  // it is generating new object it is not removing orignal object still s1 pointing old object
		System.out.println(s1.length());
		System.out.println(s2.length());
	}
}
