package com.rst;
class O 
{
	public static void main(String[] args) 
	{
		String s1 = null; //null
		String s2 = s1 + null; // nullnull
		String s3 = null + s1; // nullnull
		String s4 = "abc" + null; // abcnull
		String s5 = s1 + "xyz"; //nullnullxyz
		String s6 = s1 + s1; //nullnull
		String s7 = s1 + 2000; //null2000
		String s8 = 400 + s1; //400null  String additon
		String s9 = null + 10; //null10  //
		String s10 = 90 + null; //90null
		String s11 = 90 + 80; //170
		String s12 = null + null; //CE:
		System.out.println("Hello World!");
	}
}


/**

E:\abc-dev\string>java N
Error: Could not find or load main class N

E:\abc-dev\string>javac O.java
O.java:15: error: ';' expected
                String s11 = 90 + 80 //170
                                    ^
1 error

E:\abc-dev\string>javac O.java
O.java:13: error: bad operand types for binary operator '+'
                String s9 = null + 10; //null10
                            ^
  first type:  <null>
  second type: int
O.java:14: error: bad operand types for binary operator '+'
                String s10 = 90 + null; //90null
                             ^
  first type:  int
  second type: <null>
O.java:15: error: incompatible types: int cannot be converted to String
                String s11 = 90 + 80; //170
                                ^
O.java:16: error: bad operand types for binary operator '+'
                String s12 = null + null; //CE:
                             ^
  first type:  <null>
  second type: <null>
4 errors

E:\abc-dev\string>


*/