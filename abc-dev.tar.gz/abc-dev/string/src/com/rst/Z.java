package com.rst;
class Z 
{
	public static void main(String[] args) 
	{
		String s1 = "abcxyz";
		System.out.println(s1.charAt(0));
		char c1 = s1.charAt(3);
		System.out.println(c1);
		System.out.println(s1.charAt(20));
		System.out.println("done");


	}
}
/**
E:\abc-dev\string>java Z
a
x
Exception in thread "main" java.lang.StringIndexOutOfBoundsException: String index
        at java.lang.String.charAt(String.java:658)
        at Z.main(Z.java:9)

E:\abc-dev\string>





*/