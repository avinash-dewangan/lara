package com.rst;
class X 
{
	public static void main(String[] args) 
	{
		String s1 = " abc xyz ";
		System.out.println(s1.length());//9
		s1.trim();
		System.out.println(s1.length());//9
		System.out.println(s1.trim().length()); // it is returning 7 character
	}
}
