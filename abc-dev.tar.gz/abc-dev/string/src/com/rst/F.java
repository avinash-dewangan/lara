package com.rst;
class F 
{
	public static void main(String[] args) 
	{
		String s1 = "abc";
		System.out.println(s1);
		s1 = s1+"xyz";
		System.out.println(s1);
	}
}
