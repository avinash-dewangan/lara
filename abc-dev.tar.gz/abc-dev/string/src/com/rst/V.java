package com.rst;
class V 
{
	public static void main(String[] args) 
	{
		String s1 = "abc";

		System.out.println(s1);
		String s2 = s1.concat("xyz");
		System.out.println(s1);
		System.out.println(s2);
	}
}
