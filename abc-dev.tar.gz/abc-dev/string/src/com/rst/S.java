package com.rst;
class S
{
	public static void main(String[] args) 
	{
		String s1 = "ja";
		String s2 = "va";
		String s3 = s1+s2;
		String s4 = s1.concat(2);
		
		System.out.println(s3);
	}
}
