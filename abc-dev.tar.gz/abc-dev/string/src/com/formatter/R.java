package com.formatter;
class R
{
	public static void main(String[] args) 
	{
		int i = 23454;
		System.out.printf("(%10d)",i);
		System.out.printf("\n(%010d)",i);
	}
}