package com.formatter;
class K
{
	public static void main(String[] args) 
	{
		System.out.printf("-->%s<--",10);
		System.out.printf("-->%s<--",10.5);
		System.out.printf("-->%s<--",true);
		System.out.printf("-->%s<--",'a');		
	}
}
