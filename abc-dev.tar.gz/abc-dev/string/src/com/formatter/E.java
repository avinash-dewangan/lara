package com.formatter;

class E 
{
	public static void main(String[] args) 
	{
		String s1 = "PI value is";
		String s2= "is PI value";
		double pi = Math.PI;
		System.out.printf("%s %f",s1,pi);
		System.out.printf("\n%f%s",pi,s2);
	}
}
