package com.formatter;
class I 
{
	public static void main(String[] args) 
	{
		
		
		System.out.printf("age of a kid is %f", 1000);
		
	}
}
