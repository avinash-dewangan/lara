package com.formatter;
class Z1
{
	public static void main(String[] args) 
	{
				
		System.out.printf("%.4f",9876.453345433);
		
	}
}