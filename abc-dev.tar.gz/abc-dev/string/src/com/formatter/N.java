package com.formatter;
class N
{
	public static void main(String[] args) 
	{
		String s1 = "abc";
		System.out.printf("%1$s %1$s %1$s %1$s", s1);	
	}
}