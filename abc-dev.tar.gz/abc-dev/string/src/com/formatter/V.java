package com.formatter;
class V
{
	public static void main(String[] args) 
	{
				
		System.out.printf("(%1$0,10d)",9898989);
		
	}
}