package com.formatter;
class T
{
	public static void main(String[] args) 
	{
		int i = 23454;
		
		System.out.printf("\n(%-010d)",i); //java.util.IllegalFormatException padding only left side not right side
		
	}
}