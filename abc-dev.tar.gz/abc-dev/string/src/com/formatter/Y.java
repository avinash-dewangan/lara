package com.formatter;
class Y
{
	public static void main(String[] args) 
	{
		String s1 = "abc";		
		System.out.printf("(%,10s)",s1);
		
	}
}