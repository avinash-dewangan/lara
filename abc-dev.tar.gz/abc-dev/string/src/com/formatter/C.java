package com.formatter;

class C 
{
	public static void main(String[] args) 
	{
		String s1 = "hello";
		System.out.printf("%s)-[%s]",s1,"indian");
	}
}
