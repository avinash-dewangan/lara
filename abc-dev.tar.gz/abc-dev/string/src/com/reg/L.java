package com.reg;

class L 
{
	public static void main(String[] args) 
	{
		EUtil.find("abc123hello456java5","[1-3]"); //between c and k	
	}
}
