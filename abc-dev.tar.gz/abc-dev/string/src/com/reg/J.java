package com.reg;

class J 
{
	public static void main(String[] args) 
	{
		EUtil.find("abcfdrghsbvgdyuhsbcvs","[bj]");
		System.out.println("-----");
		EUtil.find("abcfdrghsbvgdyuhsbcvs","[b-j]"); //searching from b to j = bcdefghij
	}
}
