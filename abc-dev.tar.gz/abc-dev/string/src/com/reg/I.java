package com.reg;

class I 
{
	public static void main(String[] args) 
	{
		EUtil.find("abcbcacba","[ab]");
	}
}
