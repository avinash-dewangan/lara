package com.reg;

class W 
{
	public static void main(String[] args) 
	{
		String s1 = "x0 u0 y2 h5 p6 d4";
		String s2 = "[a-p][2-8]";

		EUtil.find(s1,s2);// 
	}
}
