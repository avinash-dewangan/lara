package com.reg;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class C 
{
	public static void main(String[] args) 
	{
		String s1 = "hellojava123javadone"; //s1 is source always pattern object define
		//           0123456789101112131415161718
		String s2 = "java"; //s2 is exprssion 
		Pattern p1 = Pattern.compile(s2);
		Matcher m1 = p1.matcher(s1);
		while(m1.find())
		{
			System.out.println(m1.group()); //group method return expression
			System.out.println(" @ ");
			System.out.println(m1.start()); //start method return index 
		}
	}
}
