package com.reg;

class P 
{
	public static void main(String[] args) 
	{
		EUtil.find("abc xyz hello","\\s"); //its location of white space @3
		
	}
}
