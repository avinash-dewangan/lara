package com.reg;
import java.util.StringTokenizer;

class Y
{
	public static void main(String[] args) 
	{
		String s1 ="helooabc2javaxy";
		String s2 = "[0-9]";
		StringTokenizer st = new StringTokenizer(s1, s2);
		while(st.hasMoreElements())
		{
			System.out.println(st.nextElement());
		}
	}
}
