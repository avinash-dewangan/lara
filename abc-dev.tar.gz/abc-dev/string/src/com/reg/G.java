package com.reg;

class G 
{
	public static void main(String[] args) 
	{
		String s1 = "hello to everybody";
		EUtil.find(s1,"e");
		System.out.println("-------");
		EUtil.find(s1,"0");
		System.out.println("-------");
	}
}
