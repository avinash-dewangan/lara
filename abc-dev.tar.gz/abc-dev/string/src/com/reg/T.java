package com.reg;

class T 
{
	public static void main(String[] args) 
	{
		String s1 = "abchello2xyz3";

		EUtil.find(s1,"[a-ep-x1-4]");// 
	}
}
