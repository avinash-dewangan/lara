package com.reg;

class R 
{
	public static void main(String[] args) 
	{
		String s1 = "sddfs2l3k4j5f5lsdfjlk2";
		String s2 = "[a-z][1-9]";
		EUtil.find(s1,s2); //D is represent other the Digits all spacial Character
		
	}
}
