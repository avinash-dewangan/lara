package com.reg;

class N 
{
	public static void main(String[] args) 
	{
		String s1 = "ab12c29hello28don%eS";
		EUtil.find(s1,"[1-9]"); 	
		System.out.println("---");
		EUtil.find(s1,"\\d"); 
	}
}
