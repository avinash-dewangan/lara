package com.dateformatter;
import java.util.Date;
import java.util.Calendar; //insted of Date class uses use Calender class\
import java.text.DateFormat;
class S 
{
	public static void main(String[] args) 
	{
		Date d1 = new Date();
		System.out.println(d1);

		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
		String s1 = df.format(d1);
		System.out.println(s1);
	}
}
