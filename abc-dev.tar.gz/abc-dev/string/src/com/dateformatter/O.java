package com.dateformatter;
import java.util.Date;
import java.util.Calendar; //insted of Date class uses use Calender class
class O 
{
	public static void main(String[] args) 
	{
		Calendar cal = Calendar.getInstance(); //Calender is a abstract class we can't create obj by using new operator use getInstance method
		Date d1 = cal.getTime();
		System.out.println(d1);
		cal.add(Calendar.DATE,30);
		Date d2 = cal.getTime();
		System.out.println(d2);
	}
}
