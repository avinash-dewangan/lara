package com.dateformatter;
import java.util.Date;
class F 
{
	public static void main(String[] args) 
	{
		Date d1 = new Date(1000*60*60*24);
		
		System.out.println(d1);
		System.out.println(d1.getTime());
	}
}
