package com.dateformatter;
import java.util.Date;
import java.util.Calendar; //insted of Date class uses use Calender class\
import java.text.DateFormat;
import java.util.Locale;
import java.text.NumberFormat;
class Z 
{
	public static void main(String[] args) 
	{
		
		NumberFormat nf1 = NumberFormat.getInstance(Locale.ITALIAN);
		NumberFormat nf2 = NumberFormat.getInstance(Locale.FRANCE);
		double num = 24555.55677;
		System.out.println(num);
		System.out.println(nf1.format(num));
		System.out.println(nf2.format(num));
	}
}
