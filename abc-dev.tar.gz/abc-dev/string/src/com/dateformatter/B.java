package com.dateformatter;
import java.util.Date;
class B 
{
	public static void main(String[] args) 
	{
		Date d1 = new Date();
		System.out.println(d1);
	}
}
