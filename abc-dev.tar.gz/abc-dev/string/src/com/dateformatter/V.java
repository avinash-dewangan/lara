package com.dateformatter;
import java.util.Date;
import java.util.Calendar; //insted of Date class uses use Calender class\
import java.text.DateFormat;
class V 
{
	public static void main(String[] args) 
	{
		Date d1 = new Date();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH,3);
		Date d1 = cal.getTime();
		
	
		DateFormat df1 = DateFormat.getDateInstance(DateFormat.LONG);
		DateFormat df2 = DateFormat.getDateInstance(DateFormat.FULL);
		DateFormat df2 = DateFormat.getDateInstance(DateFormat.FULL);
		String s1 = df1.format(d1);
		String s2 = df2.format(d1);
		System.out.println(s1);
		System.out.println(s2);
	}
}
