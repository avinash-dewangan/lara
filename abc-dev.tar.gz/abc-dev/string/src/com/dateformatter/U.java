package com.dateformatter;
import java.util.Date;
import java.util.Calendar; //insted of Date class uses use Calender class\
import java.text.DateFormat;
class U 
{
	public static void main(String[] args) 
	{
		Date d1 = new Date();
	
		DateFormat df1 = DateFormat.getDateInstance(DateFormat.LONG);
		DateFormat df2 = DateFormat.getDateInstance(DateFormat.LONG);
		String s1 = df1.format(d1);
		String s2 = df2.format(d1);
		System.out.println(s1);
		System.out.println(s2);
	}
}
