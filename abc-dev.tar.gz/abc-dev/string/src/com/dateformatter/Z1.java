package com.dateformatter;
import java.util.Date;
import java.util.Calendar; //insted of Date class uses use Calender class\
import java.text.DateFormat;
import java.util.Locale;
import java.text.NumberFormat;
import java.text.ParseException; // it is checked exception
class Z 
{
	public static void main(String[] args) 
	{
		
		Calendar cal = Calendar.getInstance();
		cal.add
	}
}
