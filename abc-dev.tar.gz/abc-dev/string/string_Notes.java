String
=======
String is sequence of Character
In order to represent there is several ways or avilable

1) char array
2) String Class
3) StringBuffer Class
4) StringBuilder Class

1)	Usage of char array to represent the multiple Character it is not advisable its very difficult to managing multiple charachter through char array


2) String :
	1	String Class is final Class its avialbale in java.lang.package.
	2	String class implementing Serializable interface because of these we can serizalize String Object.
	3	String class implementing Comparable interface because of this we can evaluate two String Object based on		the content. 
	4	Inside String class toString class Overrided because of this we can print Content of the referece it. 
	5	Inside String class hascode and equal method of an object class got overrided becuase of this we can		identify uniqueness based on the content. 
	6	we can add anything  to the String Object by using + Operator. alreday + operator Overrided to anything to		add String Object. 
	7	Java not support Operator Overloading. In C++ there is concept called Operator Overloading. In C++ there is		way to provide overloading Operator. 
	8	We can create String Object without new Operator
	9	String Object are Immutable. We can not change String Object Once we created. 

Lets go the example

3) StringBuffer :	 
	1	StringBuffer is avilable in java.lang pakcage its a final Class. 
	2	it is implementing Serializable interface because of this we can seraialize StringBuffer object.
	3	inside a StringBuffer toString method has been overrided. because of this we can print content of the object by its printing refrence variable.
	4	inside StringBuffer hashCode and equals not override becuase of this we can not evalute to String object based on the content. 
	5	StringBuffer not implementing Comparable interface becuase of this we can not sort String for based on the content.
	6	We can not create StringBuffer Object without a new Operator.
	7	StringBuffer Object are mutable(changeable).
	8	StringBuffer internally using Buffer concept what is Buffer size allocate that is Capacity.
	9	number of charater of length

4) StringBuilder - StringBuffer(1.2jkd) is Synchronized and StringBuilder is non Synchronized
   Rest all are same as StringBuffer whatever method have StrigBuffer same method have StringBuilder
   more accuracy then go to StringBuffer(1.5 jdk)



   Diffrence Between StringBuilder and StringBuffer
   ===============================================
   1 String is imutable StringBuffer is mutable
   2 String class implemtning Comparacble StringBuffer not comparable
   3 String object can be Sorted on the content StringBuffer can not be storte base on the content.
   4 String class toString(), equal() and hashCode() method all overrided. StringBuffer only toStirng method  Overrided.
   5 String we can identify uniqueness based on the content. StringBuffer we can not not identify uniqueness based on the content.
   6 String we can create Object without a new Operator. StringBuffer we can not create StringBuffer Object without a new Operator.
   7 we can add to String by using + operator
   8 String is interanlly maintaining Buffer. 	
   9 In case of String concatnation String have concat method and StringBuffer append method.
   10 Inside String class there is no reverse method and Inside StringBuffer class have reverse method
   11 inside String class no delete method but String Buffer have delete method.
   12 String is not Synchronized. but StringBuffer is Synchronized.
   13 String is not thread safe but StringBuffer is thread safe.
   14 String execution is low but StringBuffer performance is high.
   

Regular Expression
------------------
by using Matcher and pattern classes we can find multiple matches of an expression inside of the source



Format String
=============
  to represent to any argument inside formatting string % and converstion char type both is manadatory


Date
=======
in jdk there are 2 date classes one is java.util package other is java.sql package.
inside java.util pakcage there is avilable 2 constructor
1 no argument constructor 
2 one argument constructor argument data type is long
3 inside Object class toString method overrride we are printing is content rather then memory ref



