class K
{
	public static void main(String[] args) 
	{
		int x = 10;
		if(x == 10 && false)
		{
			System.out.println("insde if");
			System.out.println("end of if");
		}
		System.out.println("end of main");
	}
}
