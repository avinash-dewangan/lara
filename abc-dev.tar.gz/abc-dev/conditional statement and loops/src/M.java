class M 
{
	public static void main(String[] args) 
	{
		boolean x = true;
		if(x && !x)
		{
			System.out.println("insed if");
			System.out.println("insed end");
		}
		System.out.println("end of main");

	}
}
