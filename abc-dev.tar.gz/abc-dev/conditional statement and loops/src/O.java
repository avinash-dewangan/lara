class O 
{
	public static void main(String[] args) 
	{
		if(test())
		{
			System.out.println("insed if");
			System.out.println("insed end");
		}
		System.out.println("end of main");

	}
	static boolean test()
	{
		return true;
	}
}
