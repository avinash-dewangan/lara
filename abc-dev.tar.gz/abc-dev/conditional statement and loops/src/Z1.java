class Z1 
{
	public static void main(String[] args) 
	{
		int i = 2;
		switch(i)
		{
			case 2:System.out.println("a");
			System.out.println("b");
			case 4:System.out.println("c");
			System.out.println("d"); break;
			case 3:System.out.println("e");
			System.out.println("f");
		}
		System.out.println("g");
	}
}	
