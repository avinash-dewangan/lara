class G 
{
	public static void main(String[] args) 
	{
		boolean flag = true;
		if(!flag)
		{
			System.out.println("insde if");
			System.out.println("end of if");
		}
		System.out.println("end of main");
	}
}
