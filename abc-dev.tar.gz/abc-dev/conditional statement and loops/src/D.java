class D	 
{
	public static void main(String[] args) 
	{
		if(!true)
		System.out.println("inside if");
		System.out.println("end");
	}
}
