class R 
{
	public static void main(String[] args) 
	{
		if(test()|| test())
		{
			System.out.println("insed if");
			System.out.println("insed end");
		}
		System.out.println("end of main");

	}
	static boolean test()
	{
		System.out.println("from test");
		return false;
	}
}
