class G 
{
	{
		System.out.println("IIB1");
	}
	G()
	{
		this(80);
		System.out.println("G()");
	}
	G(int i)
	{
		System.out.println("G(int)");
	}
	public static void main(String[] args) 
	{
		G g1 = new G();
		System.out.println("----");
		G g2 = new G();
		System.out.println("----");
	}
}
