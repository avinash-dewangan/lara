package pack1;
class A 
{
	public static void main(String[] args) 
	{
		System.out.println("from pack1.A");
	}
}
//javac -d ../classes pack1/A.java