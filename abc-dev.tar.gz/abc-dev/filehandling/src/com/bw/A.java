package com.bw;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class A 
{
	public static void main(String[] args)throws IOException 
	{
		FileWriter out = new FileWriter("test.txt");
		BufferedWriter bout = new BufferedWriter(out);
		bout.write("Hello to all");
		bout.newLine();
		bout.write("Hello to all");
		bout.newLine();
		bout.flush();
		bout.close();
		out.close();
		System.out.println("Hello World!");
	}
}
