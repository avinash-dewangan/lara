package com.lara;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class S 
{
	public static void main(String[] args)throws IOException 
	{
		File f1 = new File("text.txt");
		FileReader in =  new FileReader(f1);
		
		//to store size of the file
		long size = f1.length();

		//to create character array reading character one by one
		char[] x = new char[(int)size];
		
		in.read(x);
		in.close();
		String s1 = new String(x);
		System.out.println(s1);

		System.out.println("Hello World!");
	}
}
