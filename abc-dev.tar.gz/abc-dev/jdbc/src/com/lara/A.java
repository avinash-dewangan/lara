/*
JDBC
======
complete jdbc API avilable in jdk
databse server : oracle server

under JDBC API two package avilable
1 java.sql package
2 javax.sql package

*from a java program to make a connection to the database we required one time
* from jdk 1.8 onwards no drivers are avilable in jdk
befrom jdk 1.8 there was one driver in jdk

1 Type one driver
	not use in the production
	every databse vendor or suppler prvoiding type Four driver which is only using production envirnoment
	in oracle also we are getting type 4 driver while installing orcale


	Let show type 4 driver
	go to oracle installintion
	oraclexe-app-oracle-product-11.20-server-jdbc-lib-three jar files
	in all three jar files 

	extracting the ojdbc5 file - right click go to extract here
	
	Driver class name along with package name
	=========================================
	oracle.jdbc.driver.OracleDriver
	
	this class is avilable in 
	1 ojdbc5
	2 ojdbc6
	3 ojdbc6.g

	=========================================
	
	set the class path
	===================
	D:\oraclexe\app\oracle\product\11.2.0\server\jdbc\lib\ojdbc5.jar
	if no class path avilable in your system update the class path

	classpath=D:\oraclexe\app\oracle\product\11.2.0\server\jdbc\lib\ojdbc5.jar

	go to computer - properiteis - advance system settings - enviroment vaiable

	click on new

	variable name should be "classpath"
	variable value is D:\oraclexe\app\oracle\product\11.2.0\server\jdbc\lib\ojdbc5.jar;.
	in last semicolon and dot (;.)

	click ok
	
	in order to check whether classpath proper or not
	open command window
	
	trigger javap command
	-------------------------------------
	javap oracle.jdbc.driver.OracleDriver
	-------------------------------------

	if you classpath not update class not found error

	Class.forName("oracle.jdbc.driver.OracleDriver");

	jdbc:oracle:thin:@localhost:1521:xe","user-name","password-name"




**/
package com.lara;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class A
{
	public static void main(String[] args)throws Exception
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","avinash","dewangan");
		Statement stmt = con.createStatement();
		stmt.execute("create table person(sno int, name varchar(90), age int)");		
		System.out.println("Table create successfully");
	}
}
