package com.lara;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
public class O 
{
	public static void main(String[] args)throws Exception
	{
		String sql = "select *from employee";
		Statement stmt = EUtil.getStatement();
		ResultSet rs = stmt.executeQuery(sql);
		ResultSetMetaData rsmd = rs.getMetaData();
		int col = rsmd.getColumnCount();
		for(int i =1;i<=col;i++)
		{
			System.out.print("\t"+rsmd.getColumnName(i));
		}
		System.out.println();
		while(rs.next())
		{
			System.out.print("\t"+rs.getInt(1));
			System.out.print("\t"+rs.getString(2));
			System.out.print("\t"+rs.getString(3));
			System.out.println("\t"+rs.getInt(4));

		}
		System.out.println("Hello World!");
	}
}
