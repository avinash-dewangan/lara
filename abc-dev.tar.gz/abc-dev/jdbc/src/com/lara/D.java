package com.lara;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class D
{
	public static void main(String[] args)throws Exception
	{
		//loading oracle driver in the class
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//registring the oracle deriver
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","avinash","dewangan");
		//creating Statement Object
		Statement stmt = con.createStatement();
		//passing the sql command in excute method
		String s1 = "insert into person values(5,'ravi',32)";
		String s2 = "insert into person values(6,'veena',21)";
		stmt.execute(s1);
		stmt.execute(s2);
		System.out.println("Recored Successfully Inserted");
	}
}