package com.lara;
import java.sql.Statement;
public class L
{
	public static void main(String[] args)throws Exception
	{
		Statement stmt = EUtil.getStatement();
		
		String s1 = "update employee set first_name ='changed' where sno = 8";
		stmt.execute(s1);
		System.out.println("done");
	}
}