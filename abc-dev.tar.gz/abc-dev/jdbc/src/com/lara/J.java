package com.lara;
import java.util.Set;
import java.sql.Statement;
import java.io.FileReader;
import java.util.Properties;

public class J
{
	public static void main(String[] args)throws Exception
	{
		Statement stmt = EUtil.getStatement();
		Properties pr = new Properties();
		FileReader fin = new FileReader("test2.properties");
		pr.load(fin);
		Set<String>keys = pr.stringPropertyNames();
		String value;
		for(String key : keys)
		{
			value = pr.getProperty(key);
			stmt.execute(value);
			System.out.println(value);
		}
		System.out.println("done");
	}
}