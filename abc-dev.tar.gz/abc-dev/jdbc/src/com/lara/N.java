package com.lara;
import java.sql.ResultSet;
import java.sql.Statement;

public class N 
{
	public static void main(String[] args)throws Exception 
	{
		String s1 = "select *from person";
		Statement stmt = EUtil.getStatement();
		ResultSet rs = stmt.executeQuery(s1);
		System.out.println("----By column name wise------");
		
		while(rs.next())
		{
			
			System.out.print(rs.getInt("sno"));
			System.out.print("\t");
			System.out.print(rs.getString("name"));
			System.out.print("\t");
			System.out.println(rs.getInt("age"));
			System.out.println("---------");

		}
		System.out.println("Hello World!");
	}
}
