package com.lara;

import java.sql.Statement;

public class F
{

	public static void main(String[] args)throws Exception
	{
		Statement stmt = EUtil.getStatement();
		stmt.execute("insert into person values(7,'babu',23)");
		System.out.println("record sucessfully");
	}
}