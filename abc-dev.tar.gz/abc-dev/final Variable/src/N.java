class N 
{
	final int i = 10;
	public static void main(String[] args) 
	{
		
		N n1 = new N();
		n1 = new N();
		System.out.println("done");
	}
}
