class R 
{
	final int i = 10;
	R()
	{
		i = 10;
	}
}
