class E 
{
	public static void main(String[] args) 
	{
		final E e1 = new E();
		e1 = null;
		System.out.println("done");
	}
}
