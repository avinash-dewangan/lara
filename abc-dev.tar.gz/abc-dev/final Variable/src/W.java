class W 
{
	final int i =0;
	W()
	{
		i = 0;
	}
}
