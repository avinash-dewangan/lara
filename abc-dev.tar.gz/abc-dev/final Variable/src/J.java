class J 
{
	public static void main(String[] args) 
	{
		final String[] y = new String[3];
		y = new String[3];
		System.out.println("Hello World!");
	}
}
