class T 
{
	final int i;
}
