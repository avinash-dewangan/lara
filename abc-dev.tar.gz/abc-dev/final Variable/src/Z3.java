class Z3 
{
	final int i;
	{
		i = 10;
	}
	{
		i = 10;
	}
}
